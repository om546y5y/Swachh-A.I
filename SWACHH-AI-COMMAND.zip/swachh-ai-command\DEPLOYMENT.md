# SWACHH-AI COMMAND — Deployment Checklist

## Pre-Deployment

- [ ] IBM watsonx.ai account created
- [ ] API key generated
- [ ] watsonx.ai project created
- [ ] Granite model access verified
- [ ] Environment variables configured
- [ ] JWT secret changed from default
- [ ] CORS origins restricted
- [ ] Debug mode disabled
- [ ] HTTPS certificate ready (for production)

## Local Testing

```bash
# Backend
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py

# Frontend
cd frontend
python -m http.server 3000
# Open http://localhost:3000/app.html
```

## IBM Cloud Deployment (Code Engine)

```bash
# Build container
docker build -t swachh-ai-backend ./backend

# Tag for IBM Container Registry
docker tag swachh-ai-backend us.icr.io/<namespace>/swachh-ai-backend:latest

# Push
docker push us.icr.io/<namespace>/swachh-ai-backend:latest

# Deploy to Code Engine
ibmcloud ce application create \
  --name swachh-ai-api \
  --image us.icr.io/<namespace>/swachh-ai-backend:latest \
  --env-from-secret watsonx-credentials \
  --port 8000
```

## Alternative: Traditional VPS

```bash
# Install dependencies
sudo apt update
sudo apt install python3.10 python3-pip nginx

# Clone & setup
git clone <repo> /opt/swachh-ai
cd /opt/swachh-ai/backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Run with Gunicorn
gunicorn -w 4 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000 main:app

# Nginx reverse proxy
# (see nginx.conf example)
```

## Post-Deployment Verification

- [ ] API health endpoint: `GET /health` returns 200
- [ ] Authentication working
- [ ] Granite LLM responding
- [ ] Frontend loading
- [ ] Demo scenario working
- [ ] Mobile responsive
- [ ] Logs clean
- [ ] No sensitive data exposed

## Monitoring

- IBM Cloud Monitoring for metrics
- IBM Log Analysis for logs
- Uptime monitoring (e.g., Uptime Robot)
- Error tracking (e.g., Sentry)

## Backup

- Database snapshots (if not using in-memory)
- Environment configuration backup
- Code version tagged in Git
