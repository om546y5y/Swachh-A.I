"""
SWACHH-AI COMMAND — Synthetic Seed Data
Realistic Gujarat municipal ward data for Ahmedabad.
All data is synthetic for demonstration purposes.
"""

from datetime import datetime, timedelta
import random
import uuid

# ─────────────────────────────────────────────
# WARDS — Ahmedabad Municipal Wards
# ─────────────────────────────────────────────

WARDS = [
    {
        "id": "ward_01", "name": "Ward 1 - Sabarmati", "population": 42000,
        "area_sqkm": 3.2, "households": 9800, "center": {"lat": 23.0753, "lng": 72.5893, "address": "Sabarmati"},
        "societies": ["soc_101", "soc_102", "soc_103"]
    },
    {
        "id": "ward_05", "name": "Ward 5 - Naranpura", "population": 65000,
        "area_sqkm": 4.1, "households": 15200, "center": {"lat": 23.0507, "lng": 72.5578, "address": "Naranpura"},
        "societies": ["soc_501", "soc_502", "soc_503", "soc_504"]
    },
    {
        "id": "ward_07", "name": "Ward 7 - Bapunagar", "population": 78000,
        "area_sqkm": 5.8, "households": 18600, "center": {"lat": 23.0392, "lng": 72.6215, "address": "Bapunagar"},
        "societies": ["soc_701", "soc_702", "soc_703", "soc_704", "soc_705"]
    },
    {
        "id": "ward_10", "name": "Ward 10 - Maninagar", "population": 58000,
        "area_sqkm": 4.5, "households": 13400, "center": {"lat": 22.9957, "lng": 72.6073, "address": "Maninagar"},
        "societies": ["soc_1001", "soc_1002", "soc_1003"]
    },
    {
        "id": "ward_12", "name": "Ward 12 - Gomtipur", "population": 82000,
        "area_sqkm": 6.2, "households": 19500, "center": {"lat": 23.0205, "lng": 72.6432, "address": "Gomtipur"},
        "societies": ["soc_1201", "soc_1202", "soc_1203", "soc_1204"]
    },
    {
        "id": "ward_15", "name": "Ward 15 - Odhav", "population": 71000,
        "area_sqkm": 7.1, "households": 16800, "center": {"lat": 22.9912, "lng": 72.6789, "address": "Odhav"},
        "societies": ["soc_1501", "soc_1502", "soc_1503"]
    },
    {
        "id": "ward_18", "name": "Ward 18 - Vatva", "population": 55000,
        "area_sqkm": 8.3, "households": 12200, "center": {"lat": 22.9654, "lng": 72.6543, "address": "Vatva"},
        "societies": ["soc_1801", "soc_1802"]
    },
]

# ─────────────────────────────────────────────
# SOCIETIES
# ─────────────────────────────────────────────

SOCIETIES = [
    {"id": "soc_701", "name": "Ramji Nagar Society", "ward_id": "ward_07", "household_count": 320,
     "location": {"lat": 23.0400, "lng": 72.6180}},
    {"id": "soc_702", "name": "Shiv Shakti Society", "ward_id": "ward_07", "household_count": 450,
     "location": {"lat": 23.0380, "lng": 72.6250}},
    {"id": "soc_703", "name": "Anand Nagar CHS", "ward_id": "ward_07", "household_count": 280,
     "location": {"lat": 23.0415, "lng": 72.6290}},
    {"id": "soc_704", "name": "Bapunagar Market Area", "ward_id": "ward_07", "household_count": 0,
     "location": {"lat": 23.0370, "lng": 72.6210}},  # commercial
    {"id": "soc_705", "name": "Krishna Park Society", "ward_id": "ward_07", "household_count": 380,
     "location": {"lat": 23.0435, "lng": 72.6175}},
    {"id": "soc_1201", "name": "Gomtipur Industrial Area", "ward_id": "ward_12", "household_count": 0,
     "location": {"lat": 23.0200, "lng": 72.6450}},
    {"id": "soc_1202", "name": "Laxmipura Society", "ward_id": "ward_12", "household_count": 520,
     "location": {"lat": 23.0225, "lng": 72.6410}},
    {"id": "soc_1203", "name": "Vishwakarma Nagar", "ward_id": "ward_12", "household_count": 410,
     "location": {"lat": 23.0185, "lng": 72.6470}},
    {"id": "soc_1204", "name": "Sukhipura CHS", "ward_id": "ward_12", "household_count": 360,
     "location": {"lat": 23.0210, "lng": 72.6395}},
    {"id": "soc_501", "name": "Naranpura CHS Block-A", "ward_id": "ward_05", "household_count": 480,
     "location": {"lat": 23.0510, "lng": 72.5560}},
    {"id": "soc_502", "name": "Satyanarayan Society", "ward_id": "ward_05", "household_count": 320,
     "location": {"lat": 23.0530, "lng": 72.5590}},
]

# ─────────────────────────────────────────────
# COLLECTION POINTS
# ─────────────────────────────────────────────

COLLECTION_POINTS = [
    # Ward 7 - Bapunagar
    {"id": "cp_701", "ward_id": "ward_07", "society_id": "soc_701", "name": "Ramji Nagar Bin Cluster",
     "location": {"lat": 23.0402, "lng": 72.6182}, "bin_capacity_kg": 200, "current_fill_percent": 87,
     "priority": 3, "waste_type_mix": {"wet": 0.55, "dry": 0.30, "mixed": 0.15}},
    {"id": "cp_702", "ward_id": "ward_07", "society_id": "soc_702", "name": "Shiv Shakti Main Gate",
     "location": {"lat": 23.0382, "lng": 72.6252}, "bin_capacity_kg": 250, "current_fill_percent": 92,
     "priority": 3, "waste_type_mix": {"wet": 0.60, "dry": 0.25, "mixed": 0.15}},
    {"id": "cp_703", "ward_id": "ward_07", "society_id": "soc_703", "name": "Anand Nagar Collection Point",
     "location": {"lat": 23.0417, "lng": 72.6292}, "bin_capacity_kg": 150, "current_fill_percent": 45,
     "priority": 1, "waste_type_mix": {"wet": 0.50, "dry": 0.40, "mixed": 0.10}},
    {"id": "cp_704", "ward_id": "ward_07", "society_id": "soc_704", "name": "Bapunagar Market Waste Point",
     "location": {"lat": 23.0372, "lng": 72.6212}, "bin_capacity_kg": 500, "current_fill_percent": 105,  # overflow!
     "priority": 3, "waste_type_mix": {"wet": 0.70, "dry": 0.20, "mixed": 0.10}},
    {"id": "cp_705", "ward_id": "ward_07", "society_id": "soc_705", "name": "Krishna Park Bin Station",
     "location": {"lat": 23.0437, "lng": 72.6177}, "bin_capacity_kg": 200, "current_fill_percent": 62,
     "priority": 2, "waste_type_mix": {"wet": 0.52, "dry": 0.35, "mixed": 0.13}},
    {"id": "cp_706", "ward_id": "ward_07", "society_id": None, "name": "Ward 7 Transfer Station",
     "location": {"lat": 23.0390, "lng": 72.6220}, "bin_capacity_kg": 1000, "current_fill_percent": 78,
     "priority": 2, "waste_type_mix": {"wet": 0.58, "dry": 0.28, "mixed": 0.14}},

    # Ward 12 - Gomtipur
    {"id": "cp_1201", "ward_id": "ward_12", "society_id": "soc_1201", "name": "Industrial Zone Bin Point",
     "location": {"lat": 23.0202, "lng": 72.6452}, "bin_capacity_kg": 600, "current_fill_percent": 70,
     "priority": 2, "waste_type_mix": {"wet": 0.20, "dry": 0.60, "hazardous": 0.20}},
    {"id": "cp_1202", "ward_id": "ward_12", "society_id": "soc_1202", "name": "Laxmipura Collection",
     "location": {"lat": 23.0227, "lng": 72.6412}, "bin_capacity_kg": 300, "current_fill_percent": 55,
     "priority": 1, "waste_type_mix": {"wet": 0.62, "dry": 0.30, "mixed": 0.08}},
    {"id": "cp_1203", "ward_id": "ward_12", "society_id": "soc_1203", "name": "Vishwakarma Nagar Point",
     "location": {"lat": 23.0187, "lng": 72.6472}, "bin_capacity_kg": 250, "current_fill_percent": 81,
     "priority": 2, "waste_type_mix": {"wet": 0.55, "dry": 0.32, "mixed": 0.13}},
    {"id": "cp_1204", "ward_id": "ward_12", "society_id": "soc_1204", "name": "Sukhipura Bin Cluster",
     "location": {"lat": 23.0212, "lng": 72.6397}, "bin_capacity_kg": 200, "current_fill_percent": 48,
     "priority": 1, "waste_type_mix": {"wet": 0.58, "dry": 0.35, "mixed": 0.07}},

    # Ward 5 - Naranpura
    {"id": "cp_501", "ward_id": "ward_05", "society_id": "soc_501", "name": "Naranpura CHS Collection",
     "location": {"lat": 23.0512, "lng": 72.5562}, "bin_capacity_kg": 300, "current_fill_percent": 40,
     "priority": 1, "waste_type_mix": {"wet": 0.50, "dry": 0.45, "mixed": 0.05}},
    {"id": "cp_502", "ward_id": "ward_05", "society_id": "soc_502", "name": "Satyanarayan Society Bin",
     "location": {"lat": 23.0532, "lng": 72.5592}, "bin_capacity_kg": 200, "current_fill_percent": 35,
     "priority": 1, "waste_type_mix": {"wet": 0.52, "dry": 0.43, "mixed": 0.05}},
]

# ─────────────────────────────────────────────
# VEHICLES
# ─────────────────────────────────────────────

VEHICLES = [
    {"id": "veh_01", "registration": "GJ-01-WM-0001", "vehicle_type": "large",
     "capacity_kg": 2000, "current_location": {"lat": 23.0405, "lng": 72.6185},
     "assigned_ward_ids": ["ward_07"], "driver_id": "drv_01", "fuel_level_pct": 85, "status": "available"},
    {"id": "veh_02", "registration": "GJ-01-WM-0002", "vehicle_type": "standard",
     "capacity_kg": 1200, "current_location": {"lat": 23.0380, "lng": 72.6250},
     "assigned_ward_ids": ["ward_07"], "driver_id": "drv_02", "fuel_level_pct": 70, "status": "available"},
    {"id": "veh_03", "registration": "GJ-01-WM-0003", "vehicle_type": "compact",
     "capacity_kg": 600, "current_location": {"lat": 23.0395, "lng": 72.6225},
     "assigned_ward_ids": ["ward_07", "ward_12"], "driver_id": "drv_03", "fuel_level_pct": 90, "status": "on_route"},
    {"id": "veh_04", "registration": "GJ-01-WM-0004", "vehicle_type": "large",
     "capacity_kg": 2000, "current_location": {"lat": 23.0200, "lng": 72.6450},
     "assigned_ward_ids": ["ward_12"], "driver_id": "drv_04", "fuel_level_pct": 60, "status": "available"},
    {"id": "veh_05", "registration": "GJ-01-WM-0005", "vehicle_type": "standard",
     "capacity_kg": 1200, "current_location": {"lat": 23.0215, "lng": 72.6430},
     "assigned_ward_ids": ["ward_12"], "driver_id": "drv_05", "fuel_level_pct": 95, "status": "available"},
    {"id": "veh_06", "registration": "GJ-01-WM-0006", "vehicle_type": "standard",
     "capacity_kg": 1200, "current_location": {"lat": 23.0510, "lng": 72.5565},
     "assigned_ward_ids": ["ward_05"], "driver_id": "drv_06", "fuel_level_pct": 80, "status": "available"},
    {"id": "veh_07", "registration": "GJ-01-WM-0007", "vehicle_type": "compact",
     "capacity_kg": 600, "current_location": {"lat": 23.0750, "lng": 72.5890},
     "assigned_ward_ids": ["ward_01"], "driver_id": "drv_07", "fuel_level_pct": 75, "status": "maintenance"},
    {"id": "veh_08", "registration": "GJ-01-WM-0008", "vehicle_type": "large",
     "capacity_kg": 2000, "current_location": {"lat": 22.9955, "lng": 72.6075},
     "assigned_ward_ids": ["ward_10"], "driver_id": "drv_08", "fuel_level_pct": 88, "status": "available"},
]

DRIVERS = [
    {"id": "drv_01", "name": "Ramesh Patel", "phone": "9876543210", "vehicle_id": "veh_01",
     "ward_ids": ["ward_07"], "shift": "morning"},
    {"id": "drv_02", "name": "Suresh Joshi", "phone": "9876543211", "vehicle_id": "veh_02",
     "ward_ids": ["ward_07"], "shift": "morning"},
    {"id": "drv_03", "name": "Nilesh Parmar", "phone": "9876543212", "vehicle_id": "veh_03",
     "ward_ids": ["ward_07", "ward_12"], "shift": "morning"},
    {"id": "drv_04", "name": "Haresh Shah", "phone": "9876543213", "vehicle_id": "veh_04",
     "ward_ids": ["ward_12"], "shift": "morning"},
    {"id": "drv_05", "name": "Kamlesh Solanki", "phone": "9876543214", "vehicle_id": "veh_05",
     "ward_ids": ["ward_12"], "shift": "afternoon"},
    {"id": "drv_06", "name": "Dinesh Rana", "phone": "9876543215", "vehicle_id": "veh_06",
     "ward_ids": ["ward_05"], "shift": "morning"},
    {"id": "drv_07", "name": "Bhavesh Mehta", "phone": "9876543216", "vehicle_id": "veh_07",
     "ward_ids": ["ward_01"], "shift": "morning"},
    {"id": "drv_08", "name": "Mahesh Trivedi", "phone": "9876543217", "vehicle_id": "veh_08",
     "ward_ids": ["ward_10"], "shift": "morning"},
]

# ─────────────────────────────────────────────
# SEGREGATION RECORDS (30 days of synthetic data)
# ─────────────────────────────────────────────

def generate_segregation_history():
    records = []
    base_date = datetime.now()

    ward_profiles = {
        "ward_07": {"base_compliance": 0.52, "trend": -0.02},  # declining
        "ward_12": {"base_compliance": 0.61, "trend": -0.015},  # slight decline
        "ward_05": {"base_compliance": 0.78, "trend": +0.005},  # good, stable
        "ward_01": {"base_compliance": 0.85, "trend": +0.01},   # high compliance
        "ward_10": {"base_compliance": 0.67, "trend": 0.0},     # stable
        "ward_15": {"base_compliance": 0.48, "trend": -0.01},   # low
        "ward_18": {"base_compliance": 0.55, "trend": +0.02},   # improving
    }

    for day_offset in range(30):
        date = (base_date - timedelta(days=day_offset)).strftime("%Y-%m-%d")
        for ward_id, profile in ward_profiles.items():
            compliance = profile["base_compliance"] + profile["trend"] * day_offset
            compliance = max(0.2, min(0.98, compliance + random.uniform(-0.05, 0.05)))
            total = random.randint(80, 150)
            compliant = int(total * compliance)
            records.append({
                "date": date,
                "ward_id": ward_id,
                "total_collections": total,
                "compliant_collections": compliant,
                "compliance_pct": round(compliance * 100, 1)
            })
    return records

# ─────────────────────────────────────────────
# WASTE VOLUME HISTORY
# ─────────────────────────────────────────────

def generate_waste_history():
    records = []
    base_date = datetime.now()

    ward_baselines = {
        "ward_07": 4200,   # high density, market area
        "ward_12": 3800,
        "ward_05": 3200,
        "ward_01": 2100,
        "ward_10": 3500,
        "ward_15": 3600,
        "ward_18": 2800,
    }

    for day_offset in range(30):
        date = (base_date - timedelta(days=day_offset)).strftime("%Y-%m-%d")
        for ward_id, base_kg in ward_baselines.items():
            day_of_week = (base_date - timedelta(days=day_offset)).weekday()
            weekend_factor = 1.20 if day_of_week >= 5 else 1.0
            trend_factor = 1.0 + (0.01 if ward_id == "ward_07" else 0.0) * day_offset  # ward 7 increasing
            noise = random.uniform(0.90, 1.10)
            total_kg = base_kg * weekend_factor * trend_factor * noise

            records.append({
                "date": date,
                "ward_id": ward_id,
                "total_kg": round(total_kg, 1),
                "wet_kg": round(total_kg * 0.55, 1),
                "dry_kg": round(total_kg * 0.30, 1),
                "mixed_kg": round(total_kg * 0.12, 1),
                "hazardous_kg": round(total_kg * 0.03, 1),
                "missed_collections": random.randint(0, 5) if ward_id in ["ward_07", "ward_15"] else random.randint(0, 2),
            })
    return records

# ─────────────────────────────────────────────
# SAMPLE COMPLAINTS (pre-seeded for demo)
# ─────────────────────────────────────────────

SAMPLE_COMPLAINTS = [
    {
        "id": "cmp_001", "ticket_id": "TKT-2024-0001",
        "text_original": "આજે અમારા વિસ્તારમાં કચરો લેવા ગાડી આવી નથી.",
        "text_english": "The garbage collection vehicle has not come to our area today.",
        "language": "gu",
        "complaint_type": "missed_collection",
        "location": {"lat": 23.0402, "lng": 72.6183, "address": "Ramji Nagar, Ward 7"},
        "ward_id": "ward_07", "urgency": 3, "priority": 3,
        "status": "clustered", "department": "Solid Waste Collection",
        "created_at": (datetime.now() - timedelta(hours=2)).isoformat(),
    },
    {
        "id": "cmp_002", "ticket_id": "TKT-2024-0002",
        "text_original": "Garbage bin near Shiv Shakti Society is overflowing since yesterday.",
        "text_english": "Garbage bin near Shiv Shakti Society is overflowing since yesterday.",
        "language": "en",
        "complaint_type": "overflowing_bin",
        "location": {"lat": 23.0383, "lng": 72.6253, "address": "Shiv Shakti Society, Ward 7"},
        "ward_id": "ward_07", "urgency": 4, "priority": 4,
        "status": "clustered", "department": "Solid Waste Collection",
        "created_at": (datetime.now() - timedelta(hours=3)).isoformat(),
    },
    {
        "id": "cmp_003", "ticket_id": "TKT-2024-0003",
        "text_original": "बापूनगर मार्केट के पास कूड़ा बहुत ज्यादा हो गया है।",
        "text_english": "There is too much garbage near Bapunagar Market.",
        "language": "hi",
        "complaint_type": "overflowing_bin",
        "location": {"lat": 23.0373, "lng": 72.6213, "address": "Bapunagar Market, Ward 7"},
        "ward_id": "ward_07", "urgency": 4, "priority": 4,
        "status": "clustered", "department": "Solid Waste Collection",
        "created_at": (datetime.now() - timedelta(hours=1, minutes=30)).isoformat(),
    },
    {
        "id": "cmp_004", "ticket_id": "TKT-2024-0004",
        "text_original": "Kachranu gaadi last 3 din thi aavi nathi - Shiv Shakti Society",
        "text_english": "Garbage vehicle has not come for last 3 days - Shiv Shakti Society",
        "language": "gu",
        "complaint_type": "missed_collection",
        "location": {"lat": 23.0381, "lng": 72.6251, "address": "Shiv Shakti Society, Ward 7"},
        "ward_id": "ward_07", "urgency": 3, "priority": 3,
        "status": "open", "department": "Solid Waste Collection",
        "created_at": (datetime.now() - timedelta(hours=4)).isoformat(),
    },
    {
        "id": "cmp_005", "ticket_id": "TKT-2024-0005",
        "text_original": "Ward 12 industrial area has hazardous waste dumped on roadside.",
        "text_english": "Ward 12 industrial area has hazardous waste dumped on roadside.",
        "language": "en",
        "complaint_type": "illegal_dumping",
        "location": {"lat": 23.0203, "lng": 72.6451, "address": "Industrial Area, Ward 12"},
        "ward_id": "ward_12", "urgency": 4, "priority": 4,
        "status": "assigned", "department": "Emergency/High Priority",
        "created_at": (datetime.now() - timedelta(hours=5)).isoformat(),
    },
    {
        "id": "cmp_006", "ticket_id": "TKT-2024-0006",
        "text_original": "Bapunagar market no kaacharo bharaai gayo chhe, su karavanu?",
        "text_english": "Bapunagar market garbage has overflowed, what should we do?",
        "language": "gu",
        "complaint_type": "overflowing_bin",
        "location": {"lat": 23.0374, "lng": 72.6211, "address": "Bapunagar Market Area, Ward 7"},
        "ward_id": "ward_07", "urgency": 4, "priority": 4,
        "status": "clustered", "department": "Solid Waste Collection",
        "created_at": (datetime.now() - timedelta(minutes=45)).isoformat(),
    },
    {
        "id": "cmp_007", "ticket_id": "TKT-2024-0007",
        "text_original": "Damaged dustbin at Krishna Park needs replacement.",
        "text_english": "Damaged dustbin at Krishna Park needs replacement.",
        "language": "en",
        "complaint_type": "damaged_bin",
        "location": {"lat": 23.0438, "lng": 72.6178, "address": "Krishna Park, Ward 7"},
        "ward_id": "ward_07", "urgency": 2, "priority": 2,
        "status": "open", "department": "Solid Waste Collection",
        "created_at": (datetime.now() - timedelta(hours=6)).isoformat(),
    },
]

# ─────────────────────────────────────────────
# COMPLAINT CLUSTERS
# ─────────────────────────────────────────────

COMPLAINT_CLUSTERS = [
    {
        "id": "clust_001",
        "complaint_ids": ["cmp_001", "cmp_004"],
        "complaint_type": "missed_collection",
        "location": {"lat": 23.0385, "lng": 72.6220, "address": "Ward 7 - Multiple locations"},
        "ward_id": "ward_07",
        "radius_meters": 600.0,
        "priority": 4,
        "status": "open",
        "incident_id": "inc_001",
        "ai_summary": "2 missed collection complaints in Ward 7. Pattern suggests systematic collection gap in Shiv Shakti Society and Ramji Nagar areas.",
        "created_at": (datetime.now() - timedelta(hours=1)).isoformat(),
    },
    {
        "id": "clust_002",
        "complaint_ids": ["cmp_002", "cmp_003", "cmp_006"],
        "complaint_type": "overflowing_bin",
        "location": {"lat": 23.0376, "lng": 72.6225, "address": "Bapunagar Market Area, Ward 7"},
        "ward_id": "ward_07",
        "radius_meters": 400.0,
        "priority": 5,
        "status": "open",
        "incident_id": "inc_002",
        "ai_summary": "3 overflowing bin complaints clustered near Bapunagar Market. HIGH PRIORITY — overflow condition confirmed. Immediate dispatch required.",
        "created_at": (datetime.now() - timedelta(minutes=30)).isoformat(),
    },
]

# ─────────────────────────────────────────────
# INCIDENTS
# ─────────────────────────────────────────────

INCIDENTS = [
    {
        "id": "inc_001",
        "title": "Missed Collection — Ward 7 Residential Zones",
        "description": "Multiple missed collection reports from Shiv Shakti Society and Ramji Nagar. Route vehicle GJ-01-WM-0002 appears to have skipped these stops.",
        "ward_id": "ward_07",
        "location": {"lat": 23.0385, "lng": 72.6220},
        "cluster_id": "clust_001",
        "complaint_ids": ["cmp_001", "cmp_004"],
        "priority": 4,
        "risk_level": "high",
        "department": "Solid Waste Collection",
        "status": "pending_approval",
        "sla_hours": 4,
        "sla_deadline": (datetime.now() + timedelta(hours=2)).isoformat(),
        "ai_recommendation": "Dispatch vehicle VEH-02 for immediate collection at Shiv Shakti Society and Ramji Nagar. Adjust tomorrow's route to add these stops as Priority 1.",
        "ai_rationale": "Two complaints from adjacent locations within 600m radius suggest a collection route skip. Vehicle VEH-02 has sufficient capacity (70% fuel, 35% utilized) to complete emergency pickup within 2 hours.",
        "requires_human_approval": True,
        "created_at": (datetime.now() - timedelta(hours=1)).isoformat(),
    },
    {
        "id": "inc_002",
        "title": "CRITICAL: Bapunagar Market Bin Overflow — 3 Complaints",
        "description": "3 complaints in 2 hours confirm bin overflow at Bapunagar Market (Collection Point cp_704). Bin is at 105% capacity. Weekend market activity causing surge.",
        "ward_id": "ward_07",
        "location": {"lat": 23.0376, "lng": 72.6225},
        "cluster_id": "clust_002",
        "complaint_ids": ["cmp_002", "cmp_003", "cmp_006"],
        "priority": 5,
        "risk_level": "critical",
        "department": "Solid Waste Collection",
        "status": "pending_approval",
        "sla_hours": 2,
        "sla_deadline": (datetime.now() + timedelta(hours=1)).isoformat(),
        "ai_recommendation": "Emergency dispatch: Route VEH-01 (large capacity, 85% fuel) to Bapunagar Market immediately. Add VEH-03 as backup if VEH-01 insufficient. Notify Market Area authorities.",
        "ai_rationale": "Overflow bin with 3 confirmed complaints in 2-hour window indicates urgent public health risk. Historical data shows Bapunagar Market generates 32% more waste on weekends. VEH-01 capacity (2000kg) and proximity (0.4km) makes it optimal choice.",
        "requires_human_approval": True,
        "created_at": (datetime.now() - timedelta(minutes=25)).isoformat(),
    },
    {
        "id": "inc_003",
        "title": "Hazardous Waste — Ward 12 Industrial Area",
        "description": "Illegal roadside dumping of industrial/hazardous waste in Ward 12.",
        "ward_id": "ward_12",
        "location": {"lat": 23.0203, "lng": 72.6451},
        "cluster_id": None,
        "complaint_ids": ["cmp_005"],
        "priority": 5,
        "risk_level": "critical",
        "department": "Emergency/High Priority",
        "status": "approved",
        "sla_hours": 2,
        "sla_deadline": (datetime.now() + timedelta(hours=0, minutes=30)).isoformat(),
        "ai_recommendation": "Dispatch specialized hazardous waste team. Cordon area. Notify pollution control board.",
        "ai_rationale": "Hazardous waste on public roadway poses immediate health risk. Requires specialized handling team with protective equipment.",
        "requires_human_approval": True,
        "approved_by": "officer_01",
        "approved_at": (datetime.now() - timedelta(hours=4, minutes=30)).isoformat(),
        "created_at": (datetime.now() - timedelta(hours=5)).isoformat(),
    },
]

# ─────────────────────────────────────────────
# HOTSPOT PREDICTIONS
# ─────────────────────────────────────────────

HOTSPOT_PREDICTIONS = [
    {
        "id": "hot_001",
        "ward_id": "ward_07",
        "location": {"lat": 23.0374, "lng": 72.6213, "address": "Bapunagar Market Area"},
        "name": "Bapunagar Market Area",
        "risk_level": "critical",
        "risk_score": 94.2,
        "reasons": [
            "Current fill level: 105% (overflowing)",
            "3 active complaints in last 2 hours",
            "Weekend — market activity +40%",
            "Historical waste volume +32% above baseline",
            "Last collection: 18 hours ago (delayed)",
            "No scheduled collection in next 3 hours"
        ],
        "recommendation": "Dispatch emergency collection vehicle immediately. Schedule additional collection between 6 PM and 8 PM.",
        "expected_impact": "Overflow resolved within 1 hour. Public health risk eliminated. Waste backlog cleared by 8 PM.",
        "predicted_overflow_time": datetime.now().isoformat(),
        "ai_confidence": 0.94,
        "data_inputs": {"complaints": 3, "fill_pct": 105, "hours_since_collection": 18, "waste_volume_trend": "+32%"},
        "created_at": (datetime.now() - timedelta(minutes=15)).isoformat(),
    },
    {
        "id": "hot_002",
        "ward_id": "ward_07",
        "location": {"lat": 23.0382, "lng": 72.6251, "address": "Shiv Shakti Society Gate"},
        "name": "Shiv Shakti Society Area",
        "risk_level": "high",
        "risk_score": 78.5,
        "reasons": [
            "Bin at 92% capacity",
            "2 missed collection complaints",
            "3-day collection gap reported",
            "Segregation compliance: 41% (low)",
            "Increasing waste volume trend (+15%)"
        ],
        "recommendation": "Priority collection dispatch. Send compliance officer for segregation inspection. Issue educational nudge to residents.",
        "expected_impact": "Prevents overflow within 4 hours. Compliance nudge may improve segregation by 10-15% over 2 weeks.",
        "predicted_overflow_time": (datetime.now() + timedelta(hours=4)).isoformat(),
        "ai_confidence": 0.82,
        "data_inputs": {"fill_pct": 92, "complaints": 2, "compliance_pct": 41, "collection_gap_days": 3},
        "created_at": (datetime.now() - timedelta(minutes=20)).isoformat(),
    },
    {
        "id": "hot_003",
        "ward_id": "ward_12",
        "location": {"lat": 23.0187, "lng": 72.6473, "address": "Vishwakarma Nagar Area"},
        "name": "Vishwakarma Nagar - Ward 12",
        "risk_level": "medium",
        "risk_score": 56.3,
        "reasons": [
            "Bin at 81% capacity",
            "Segregation compliance declining (-11% this week)",
            "Collection delay pattern on Thursdays",
            "Population density increasing"
        ],
        "recommendation": "Schedule collection within 6 hours. Issue segregation reminder to residents.",
        "expected_impact": "Prevents overflow. Compliance nudge may stabilize segregation scores.",
        "predicted_overflow_time": (datetime.now() + timedelta(hours=12)).isoformat(),
        "ai_confidence": 0.71,
        "data_inputs": {"fill_pct": 81, "compliance_decline_pct": 11, "collection_delay_pattern": "Thursday"},
        "created_at": (datetime.now() - timedelta(minutes=25)).isoformat(),
    },
]

# ─────────────────────────────────────────────
# WARD ANALYTICS (current)
# ─────────────────────────────────────────────

WARD_ANALYTICS_CURRENT = [
    {
        "ward_id": "ward_07", "ward_name": "Ward 7 - Bapunagar",
        "date": datetime.now().strftime("%Y-%m-%d"),
        "total_waste_kg": 4820, "wet_waste_pct": 58, "dry_waste_pct": 28, "mixed_waste_pct": 11, "hazardous_waste_pct": 3,
        "segregation_compliance_pct": 49.2, "missed_collections": 7, "total_collections": 142,
        "open_grievances": 5, "resolved_grievances": 18, "avg_resolution_hours": 5.8,
        "route_efficiency_pct": 71.3, "vehicle_utilization_pct": 83.1, "cleanliness_score": 52.4,
        "active_hotspots": 2,
        "ai_insight": "Ward 7 is under stress: compliance down 11%, overflow incidents up, and 2 critical hotspots active.",
        "ai_what_happened": "Ward 7 segregation compliance dropped from 60.1% to 49.2% over 7 days. Missed collections increased from 3 to 7 this week. Bapunagar Market bin overflow reached critical status with 3 citizen complaints.",
        "ai_why": "Weekend market activity generated 32% excess waste. Vehicle VEH-02 route deviation skipped 2 collection points. Low segregation compliance in Shiv Shakti Society (41%) suggests inadequate community awareness.",
        "ai_recommendation": "1) Emergency collection at Bapunagar Market immediately. 2) Reallocate VEH-01 for Ward 7 from 6-8 PM. 3) Deploy segregation compliance officer to Shiv Shakti Society. 4) Send multilingual nudge to Ward 7 residents.",
        "ai_do_nothing_impact": "If no action taken: Bapunagar Market will remain an overflowing public health risk for 12+ hours. Compliance score will likely drop further to ~42% by week-end. 3 additional overflow incidents expected tomorrow.",
        "trend_waste_7d": [4120, 4350, 4180, 4480, 4620, 4710, 4820],
        "trend_compliance_7d": [60.1, 58.4, 56.2, 54.9, 52.1, 50.8, 49.2],
        "trend_complaints_7d": [2, 3, 2, 4, 5, 6, 7],
    },
    {
        "ward_id": "ward_12", "ward_name": "Ward 12 - Gomtipur",
        "date": datetime.now().strftime("%Y-%m-%d"),
        "total_waste_kg": 3920, "wet_waste_pct": 52, "dry_waste_pct": 32, "mixed_waste_pct": 11, "hazardous_waste_pct": 5,
        "segregation_compliance_pct": 61.4, "missed_collections": 3, "total_collections": 138,
        "open_grievances": 3, "resolved_grievances": 24, "avg_resolution_hours": 4.2,
        "route_efficiency_pct": 78.5, "vehicle_utilization_pct": 77.4, "cleanliness_score": 63.8,
        "active_hotspots": 1,
        "ai_insight": "Ward 12 compliance declining slightly. One critical hazardous waste incident being addressed.",
        "ai_what_happened": "Ward 12 segregation compliance decreased by 8% this week. One critical hazardous waste illegal dumping incident in industrial area.",
        "ai_why": "Industrial zone has minimal compliance oversight. Three residential societies showing declining wet/dry separation.",
        "ai_recommendation": "Deploy inspection team to industrial area. Issue compliance notice to Laxmipura and Vishwakarma Nagar societies.",
        "ai_do_nothing_impact": "Hazardous waste incident will escalate. Compliance will likely fall below 55% within 2 weeks.",
        "trend_waste_7d": [3620, 3750, 3680, 3820, 3880, 3910, 3920],
        "trend_compliance_7d": [69.2, 68.1, 66.4, 65.8, 64.2, 62.9, 61.4],
        "trend_complaints_7d": [1, 2, 1, 2, 3, 3, 4],
    },
    {
        "ward_id": "ward_05", "ward_name": "Ward 5 - Naranpura",
        "date": datetime.now().strftime("%Y-%m-%d"),
        "total_waste_kg": 3180, "wet_waste_pct": 51, "dry_waste_pct": 43, "mixed_waste_pct": 5, "hazardous_waste_pct": 1,
        "segregation_compliance_pct": 79.6, "missed_collections": 1, "total_collections": 145,
        "open_grievances": 1, "resolved_grievances": 31, "avg_resolution_hours": 2.9,
        "route_efficiency_pct": 88.2, "vehicle_utilization_pct": 69.3, "cleanliness_score": 81.5,
        "active_hotspots": 0,
        "ai_insight": "Ward 5 performing well. High compliance and efficient routes. Model ward for city.",
        "ai_what_happened": "Ward 5 maintained 79.6% compliance. Only 1 missed collection this week. No overflow incidents.",
        "ai_why": "High-compliance RWA engagements and regular door-to-door awareness drives are effective.",
        "ai_recommendation": "Continue current practices. Use Ward 5 as model for low-compliance wards.",
        "ai_do_nothing_impact": "Performance will remain stable. Minor risk if collection schedule changes.",
        "trend_waste_7d": [3050, 3120, 3080, 3150, 3160, 3170, 3180],
        "trend_compliance_7d": [77.1, 78.2, 77.8, 79.0, 79.3, 79.5, 79.6],
        "trend_complaints_7d": [2, 1, 1, 0, 1, 1, 1],
    },
]

# ─────────────────────────────────────────────
# CIRCULAR ECONOMY BASELINE
# ─────────────────────────────────────────────

CIRCULAR_ECONOMY_DATA = {
    "ward_07": {
        "total_waste_monthly_kg": 144000,
        "current_recycling_rate": 0.18,
        "current_composting_rate": 0.08,
        "potential_recycling_rate": 0.42,
        "potential_composting_rate": 0.35,
        "dry_waste_composition": {
            "paper": 0.30, "plastic": 0.28, "metal": 0.12,
            "glass": 0.08, "textile": 0.10, "other": 0.12
        },
        "wet_waste_composition": {
            "food_waste": 0.72, "garden": 0.15, "other_organic": 0.13
        }
    }
}

# Recovery value per ton (INR) — estimated market rates
MATERIAL_RECOVERY_VALUES = {
    "paper": 8000,
    "plastic_hdpe": 12000,
    "plastic_pet": 10000,
    "metal": 25000,
    "glass": 4000,
    "textile": 6000,
    "compost": 3000,
    "e_waste": 40000,
}

SEGREGATION_HISTORY = generate_segregation_history()
WASTE_HISTORY = generate_waste_history()

# ─────────────────────────────────────────────
# OFFICERS / USERS
# ─────────────────────────────────────────────

OFFICERS = [
    {"id": "officer_01", "name": "Priya Sharma", "role": "Ward Officer", "ward_ids": ["ward_07", "ward_12"],
     "phone": "9988776655", "email": "priya.sharma@ahmedabad.gov.in"},
    {"id": "officer_02", "name": "Raj Patel", "role": "Zone Supervisor", "ward_ids": ["ward_05", "ward_01", "ward_10"],
     "phone": "9988776644", "email": "raj.patel@ahmedabad.gov.in"},
    {"id": "officer_03", "name": "Meera Joshi", "role": "Sanitation Inspector", "ward_ids": ["ward_15", "ward_18"],
     "phone": "9988776633", "email": "meera.joshi@ahmedabad.gov.in"},
    {"id": "supervisor_01", "name": "Ramanbhai Desai", "role": "Collection Supervisor", "ward_ids": ["ward_07"],
     "phone": "9988776622", "email": "rdesai@ahmedabad.gov.in"},
]

DEMO_USERS = [
    {"username": "officer", "password": "demo123", "role": "Ward Officer", "id": "officer_01", "name": "Priya Sharma"},
    {"username": "supervisor", "password": "demo123", "role": "Collection Supervisor", "id": "supervisor_01", "name": "Ramanbhai Desai"},
    {"username": "citizen", "password": "demo123", "role": "Citizen", "id": "cit_001", "name": "Demo Citizen"},
    {"username": "admin", "password": "admin123", "role": "Admin", "id": "admin_01", "name": "System Admin"},
]
