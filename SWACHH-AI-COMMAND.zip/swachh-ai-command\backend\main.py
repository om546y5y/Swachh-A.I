"""
SWACHH-AI COMMAND — FastAPI Main Application
Production-ready REST API with all routes, auth middleware, CORS, and docs.
"""

import os
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Optional, List

import jwt
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from backend.agents.orchestrator import orchestrator
from backend.agents.route_optimization_agent import route_agent
from backend.agents.grievance_agent import grievance_agent
from backend.agents.municipal_routing_agent import routing_agent
from backend.agents.segregation_compliance_agent import compliance_agent
from backend.agents.hotspot_agent import hotspot_agent
from backend.agents.ward_analytics_agent import analytics_agent
from backend.agents.circular_economy_agent import circular_agent
from backend.data.seed_data import DEMO_USERS, WARDS, VEHICLES, COLLECTION_POINTS

# ─────────────────────────────────────────────
# APP CONFIG
# ─────────────────────────────────────────────

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

JWT_SECRET = os.getenv("JWT_SECRET", "swachh-ai-command-secret-key-2024")
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_HOURS = 12

app = FastAPI(
    title="SWACHH-AI COMMAND API",
    description="Agentic AI platform for Gujarat Municipal Solid Waste Management",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production: restrict to known origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

security = HTTPBearer(auto_error=False)


# ─────────────────────────────────────────────
# AUTH
# ─────────────────────────────────────────────

class LoginRequest(BaseModel):
    username: str
    password: str

def create_token(user: dict) -> str:
    payload = {
        "sub": user["id"],
        "username": user["username"],
        "role": user["role"],
        "name": user.get("name", ""),
        "exp": datetime.utcnow() + timedelta(hours=JWT_EXPIRE_HOURS),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

def require_officer(user=Depends(verify_token)):
    if user.get("role") not in ("Ward Officer", "Collection Supervisor", "Admin"):
        raise HTTPException(status_code=403, detail="Officer access required")
    return user


# ─────────────────────────────────────────────
# HEALTH & AUTH ROUTES
# ─────────────────────────────────────────────

@app.get("/", tags=["Health"])
async def root():
    return {"status": "operational", "system": "SWACHH-AI COMMAND",
            "version": "1.0.0", "tagline": "Predict. Act. Verify. Optimize."}

@app.get("/health", tags=["Health"])
async def health():
    return {"status": "healthy", "agents": 7, "timestamp": datetime.now().isoformat()}

@app.post("/auth/login", tags=["Auth"])
async def login(req: LoginRequest):
    user = next((u for u in DEMO_USERS
                 if u["username"] == req.username and u["password"] == req.password), None)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_token(user)
    return {"access_token": token, "token_type": "bearer",
            "role": user["role"], "name": user.get("name", "")}

@app.get("/auth/me", tags=["Auth"])
async def me(user=Depends(verify_token)):
    return user


# ─────────────────────────────────────────────
# GRIEVANCE / CITIZEN ROUTES
# ─────────────────────────────────────────────

class GrievanceInput(BaseModel):
    text: str
    language: Optional[str] = None
    location: Optional[dict] = None
    location_description: Optional[str] = None
    citizen_phone: Optional[str] = None
    ward_id: Optional[str] = None

@app.post("/api/grievance/submit", tags=["Citizen"])
async def submit_grievance(request: GrievanceInput):
    """Submit a citizen complaint. Supports Gujarati, Hindi, English."""
    result = await orchestrator.handle_grievance_workflow(request.dict())
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result.get("error", "Processing failed"))
    return result

@app.get("/api/grievance/ticket/{ticket_id}", tags=["Citizen"])
async def get_ticket(ticket_id: str):
    complaint = grievance_agent.get_complaint_by_ticket(ticket_id)
    if not complaint:
        raise HTTPException(status_code=404, detail="Ticket not found")
    return complaint

@app.get("/api/grievance/complaints", tags=["Officer"])
async def get_complaints(
    ward_id: Optional[str] = None,
    status: Optional[str] = None,
    user=Depends(verify_token)
):
    return {"complaints": grievance_agent.get_all_complaints(ward_id, status)}

@app.get("/api/grievance/clusters", tags=["Officer"])
async def get_clusters(ward_id: Optional[str] = None, user=Depends(verify_token)):
    return {"clusters": grievance_agent.get_clusters(ward_id)}


# ─────────────────────────────────────────────
# ROUTE OPTIMIZATION
# ─────────────────────────────────────────────

@app.post("/api/routes/optimize", tags=["Operations"])
async def optimize_routes(
    ward_id: str, date: Optional[str] = None,
    shift: str = "morning", user=Depends(require_officer)
):
    if not date:
        date = datetime.now().strftime("%Y-%m-%d")
    routes = await route_agent.optimize_routes(ward_id, date, shift)
    return {"routes": routes, "count": len(routes), "optimized_at": datetime.now().isoformat()}

@app.get("/api/routes/current/{ward_id}", tags=["Operations"])
async def get_current_routes(ward_id: str, user=Depends(verify_token)):
    routes = await route_agent.optimize_routes(ward_id, datetime.now().strftime("%Y-%m-%d"))
    return {"routes": routes}

@app.post("/api/routes/whatif", tags=["Operations"])
async def route_what_if(
    ward_id: str,
    waste_multiplier: float = 1.0,
    vehicles_available: Optional[int] = None,
    user=Depends(require_officer)
):
    """What-if route simulation."""
    result = await route_agent.what_if_simulation(ward_id, waste_multiplier, vehicles_available)
    return result


# ─────────────────────────────────────────────
# INCIDENTS & APPROVALS
# ─────────────────────────────────────────────

class ApprovalInput(BaseModel):
    officer_id: str
    decision: str  # approve, reject, modify
    reason: Optional[str] = None

@app.get("/api/incidents", tags=["Officer"])
async def get_incidents(
    ward_id: Optional[str] = None,
    status: Optional[str] = None,
    user=Depends(verify_token)
):
    return {"incidents": routing_agent.get_all_incidents(ward_id, status)}

@app.get("/api/incidents/pending", tags=["Officer"])
async def get_pending_approvals(user=Depends(require_officer)):
    return {"pending": routing_agent.get_pending_approvals()}

@app.post("/api/incidents/{incident_id}/approve", tags=["Officer"])
async def approve_incident(
    incident_id: str, body: ApprovalInput,
    user=Depends(require_officer)
):
    result = await routing_agent.approve_incident(
        incident_id, body.officer_id, body.decision, body.reason
    )
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result.get("error"))
    return result

@app.post("/api/incidents/{incident_id}/resolve", tags=["Officer"])
async def resolve_incident(
    incident_id: str,
    resolved_by: str,
    notes: Optional[str] = None,
    user=Depends(require_officer)
):
    return await routing_agent.resolve_incident(incident_id, resolved_by, notes)

@app.get("/api/incidents/sla-check", tags=["Officer"])
async def check_sla(user=Depends(require_officer)):
    breaches = await routing_agent.check_sla_breaches()
    return {"breaches": breaches, "count": len(breaches)}

@app.get("/api/audit-logs", tags=["Admin"])
async def get_audit_logs(user=Depends(require_officer)):
    return {"logs": routing_agent.get_audit_logs()}


# ─────────────────────────────────────────────
# COMPLIANCE & NUDGES
# ─────────────────────────────────────────────

@app.get("/api/compliance/scores", tags=["Analytics"])
async def get_compliance_scores(user=Depends(verify_token)):
    return {"scores": compliance_agent.get_all_ward_scores()}

@app.get("/api/compliance/{ward_id}", tags=["Analytics"])
async def get_ward_compliance(ward_id: str, user=Depends(verify_token)):
    return compliance_agent.get_ward_compliance_score(ward_id)

@app.get("/api/compliance/{ward_id}/waste-breakdown", tags=["Analytics"])
async def get_waste_breakdown(ward_id: str, days: int = 7, user=Depends(verify_token)):
    return compliance_agent.get_waste_type_breakdown(ward_id, days)

@app.post("/api/compliance/{ward_id}/nudge", tags=["Operations"])
async def generate_nudge(ward_id: str, language: str = "en", user=Depends(require_officer)):
    nudge = await compliance_agent.generate_nudge_for_ward(ward_id, language)
    return nudge

@app.post("/api/compliance/{ward_id}/nudge/all", tags=["Operations"])
async def generate_all_nudges(ward_id: str, user=Depends(require_officer)):
    nudges = await compliance_agent.generate_multilingual_nudges(ward_id)
    return {"nudges": nudges}

@app.get("/api/compliance/{ward_id}/timeline", tags=["Analytics"])
async def get_compliance_timeline(ward_id: str, days: int = 30, user=Depends(verify_token)):
    return {"timeline": compliance_agent.get_compliance_timeline(ward_id, days)}


# ─────────────────────────────────────────────
# HOTSPOT PREDICTIONS
# ─────────────────────────────────────────────

@app.get("/api/hotspots", tags=["Analytics"])
async def get_hotspots(ward_id: Optional[str] = None, user=Depends(verify_token)):
    predictions = await hotspot_agent.predict_hotspots(ward_id)
    return {"predictions": predictions, "summary": hotspot_agent.get_hotspot_summary()}

@app.get("/api/hotspots/summary", tags=["Analytics"])
async def get_hotspot_summary(user=Depends(verify_token)):
    return hotspot_agent.get_hotspot_summary()


# ─────────────────────────────────────────────
# WARD ANALYTICS
# ─────────────────────────────────────────────

@app.get("/api/analytics/city", tags=["Analytics"])
async def get_city_analytics(user=Depends(verify_token)):
    return analytics_agent.get_city_summary()

@app.get("/api/analytics/wards", tags=["Analytics"])
async def get_all_ward_analytics(user=Depends(verify_token)):
    return {"wards": analytics_agent.get_all_ward_analytics()}

@app.get("/api/analytics/{ward_id}", tags=["Analytics"])
async def get_ward_analytics(ward_id: str, user=Depends(verify_token)):
    data = analytics_agent.get_ward_analytics(ward_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"No analytics for {ward_id}")
    return data

@app.get("/api/analytics/{ward_id}/insights", tags=["Analytics"])
async def get_ward_insights(ward_id: str, user=Depends(verify_token)):
    insights = await analytics_agent.get_ward_ai_insights(ward_id)
    return insights

@app.get("/api/analytics/{ward_id}/trend/{metric}", tags=["Analytics"])
async def get_trend(ward_id: str, metric: str, days: int = 30, user=Depends(verify_token)):
    return {"trend": analytics_agent.get_trend_data(ward_id, metric, days)}

@app.get("/api/analytics/impact/comparison", tags=["Analytics"])
async def get_impact_comparison(user=Depends(verify_token)):
    return analytics_agent.get_impact_comparison()


# ─────────────────────────────────────────────
# CIRCULAR ECONOMY
# ─────────────────────────────────────────────

@app.get("/api/circular/{ward_id}", tags=["Circular Economy"])
async def get_circular_report(ward_id: str, user=Depends(verify_token)):
    return await circular_agent.get_ward_circular_report(ward_id)

@app.get("/api/circular/city/summary", tags=["Circular Economy"])
async def get_city_circular_summary(user=Depends(verify_token)):
    return circular_agent.get_city_circular_summary()


# ─────────────────────────────────────────────
# AGENT ACTIVITY & ORCHESTRATION
# ─────────────────────────────────────────────

@app.get("/api/agents/activity", tags=["Agents"])
async def get_agent_activity(limit: int = 30, user=Depends(verify_token)):
    return {"activities": orchestrator.get_activity_stream(limit)}

@app.get("/api/agents/status", tags=["Agents"])
async def get_agent_status(user=Depends(verify_token)):
    return {"agents": orchestrator.get_agent_statuses()}

@app.post("/api/agents/scan", tags=["Agents"])
async def run_morning_scan(
    ward_ids: Optional[List[str]] = None,
    user=Depends(require_officer)
):
    result = await orchestrator.run_morning_scan(ward_ids)
    return result

@app.post("/api/demo/hero-scenario", tags=["Demo"])
async def run_hero_demo(user=Depends(verify_token)):
    """Run the complete hero demo scenario for hackathon presentation."""
    result = await orchestrator.run_hero_demo()
    return result


# ─────────────────────────────────────────────
# WHAT-IF SIMULATION (comprehensive)
# ─────────────────────────────────────────────

class WhatIfInput(BaseModel):
    ward_id: str
    waste_volume_change_pct: float = 0.0
    vehicles_available: Optional[int] = None
    collection_delay_hours: float = 0.0
    segregation_rate_pct: Optional[float] = None
    notes: Optional[str] = None

@app.post("/api/simulation/whatif", tags=["Simulation"])
async def what_if_simulation(body: WhatIfInput, user=Depends(verify_token)):
    """Comprehensive what-if simulation across all impact dimensions."""
    multiplier = 1.0 + (body.waste_volume_change_pct / 100.0)

    # Route impact
    route_sim = await route_agent.what_if_simulation(
        body.ward_id, multiplier, body.vehicles_available
    )

    # Compliance impact
    compliance_data = compliance_agent.get_ward_compliance_score(body.ward_id)
    current_compliance = compliance_data.get("score", 60)
    projected_compliance = (
        body.segregation_rate_pct if body.segregation_rate_pct
        else max(20, current_compliance - (body.waste_volume_change_pct * 0.3))
    )

    # Overflow risk
    overflow_risk_map = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}
    risk_labels = {1: "LOW", 2: "MEDIUM", 3: "HIGH", 4: "CRITICAL"}
    base_risk = overflow_risk_map.get(route_sim["overflow_risk"], 2)
    delay_factor = int(body.collection_delay_hours / 6)
    new_risk_level = risk_labels.get(min(4, base_risk + delay_factor), "HIGH")

    return {
        "scenario": body.dict(),
        "route_impact": route_sim,
        "compliance_impact": {
            "current_compliance_pct": round(current_compliance, 1),
            "projected_compliance_pct": round(projected_compliance, 1),
            "change_pct": round(projected_compliance - current_compliance, 1),
        },
        "overflow_risk": new_risk_level,
        "complaint_backlog_change_pct": round(body.waste_volume_change_pct * 1.8, 1),
        "ward_score_change": round(-body.waste_volume_change_pct * 0.4, 1),
        "mitigation_steps": route_sim.get("mitigation_steps", []),
        "note": "DEMO SIMULATION — Estimated figures only",
        "simulated_at": datetime.now().isoformat(),
    }


# ─────────────────────────────────────────────
# DATA ENDPOINTS (read-only reference data)
# ─────────────────────────────────────────────

@app.get("/api/data/wards", tags=["Data"])
async def get_wards():
    return {"wards": WARDS}

@app.get("/api/data/vehicles", tags=["Data"])
async def get_vehicles(user=Depends(verify_token)):
    return {"vehicles": VEHICLES}

@app.get("/api/data/collection-points", tags=["Data"])
async def get_collection_points(ward_id: Optional[str] = None, user=Depends(verify_token)):
    points = COLLECTION_POINTS
    if ward_id:
        points = [cp for cp in points if cp["ward_id"] == ward_id]
    return {"collection_points": points}


# ─────────────────────────────────────────────
# STARTUP
# ─────────────────────────────────────────────

@app.on_event("startup")
async def startup_event():
    logger.info("=" * 60)
    logger.info("SWACHH-AI COMMAND — Municipal Waste AI Platform")
    logger.info("Predict. Act. Verify. Optimize.")
    logger.info("=" * 60)
    logger.info("7 AI Agents initialized and ready.")
    logger.info("IBM Granite LLM integration active.")
    # Run initial morning scan in background
    asyncio.create_task(orchestrator.run_morning_scan(["ward_07", "ward_12"]))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
