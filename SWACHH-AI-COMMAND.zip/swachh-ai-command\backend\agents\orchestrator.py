"""
SWACHH-AI COMMAND — Agent Orchestrator
Coordinates all 7 agents. Manages event-driven workflows.
Provides real-time agent activity streaming.
"""

import uuid
import asyncio
import logging
from datetime import datetime
from typing import List, Dict, Any, Optional, Callable

from backend.agents.route_optimization_agent import route_agent
from backend.agents.grievance_agent import grievance_agent
from backend.agents.municipal_routing_agent import routing_agent
from backend.agents.segregation_compliance_agent import compliance_agent
from backend.agents.hotspot_agent import hotspot_agent
from backend.agents.ward_analytics_agent import analytics_agent
from backend.agents.circular_economy_agent import circular_agent

logger = logging.getLogger(__name__)

# In-memory workflow activity log (production: Redis pub/sub or IBM Event Streams)
_workflow_log: List[Dict] = []
_activity_stream: List[Dict] = []


def _emit_activity(agent_name: str, action: str, detail: str,
                   status: str = "active", related_ids: Optional[List[str]] = None):
    """Emit an agent activity event to the stream."""
    event = {
        "id": str(uuid.uuid4()),
        "agent_name": agent_name,
        "action": action,
        "detail": detail,
        "status": status,
        "timestamp": datetime.now().isoformat(),
        "related_ids": related_ids or [],
    }
    _activity_stream.append(event)
    # Keep only last 200 events
    if len(_activity_stream) > 200:
        _activity_stream.pop(0)
    logger.info(f"[{agent_name}] {action}: {detail[:80]}")
    return event


class AgentOrchestrator:
    """
    Central orchestrator. Receives triggers, coordinates agents,
    manages human-in-the-loop checkpoints, streams activity.
    """

    def __init__(self):
        self.name = "Agent Orchestrator"
        logger.info("SWACHH-AI COMMAND Orchestrator initialized. All agents ready.")

    # ──────────────────────────────────────────
    # WORKFLOW: Process new citizen grievance
    # ──────────────────────────────────────────

    async def handle_grievance_workflow(self, request: Dict) -> Dict[str, Any]:
        """
        End-to-end grievance processing workflow.
        CITIZEN INPUT → CLASSIFY → CLUSTER → INCIDENT → ROUTE → NOTIFY
        """
        workflow_id = str(uuid.uuid4())
        _emit_activity("Grievance Agent", "Receiving Complaint",
                        f"New grievance received. Processing...", "active", [workflow_id])

        # Step 1: Grievance intake + Granite classification
        result = await grievance_agent.process_complaint(request)
        if not result.get("success"):
            _emit_activity("Grievance Agent", "Error", "Failed to process complaint", "error")
            return result

        ticket_id = result["ticket_id"]
        complaint_id = result["complaint_id"]
        _emit_activity("Grievance Agent", "Complaint Classified",
                        f"[{ticket_id}] {result['complaint_type'].replace('_',' ').title()} | "
                        f"Language: {result['detected_language'].upper()} | Priority: {result['priority']}/4",
                        "completed", [ticket_id])

        # Step 2: Check clusters and create incidents
        cluster_info = result.get("cluster_info")
        if cluster_info:
            cluster_size = cluster_info.get("cluster_size", 1)
            _emit_activity("Municipal Routing Agent", "Cluster Detected",
                            f"⚠️ {cluster_size} complaints clustered near same location. "
                            f"Priority elevated to {cluster_info['priority']}/5.",
                            "completed", [cluster_info["cluster_id"]])

            # Auto-create incident from cluster
            clusters = grievance_agent.get_clusters()
            matching = next((c for c in clusters if c["id"] == cluster_info["cluster_id"]), None)
            if matching:
                complaints = grievance_agent.get_all_complaints()
                incident = await routing_agent.create_incident_from_cluster(matching, complaints)
                _emit_activity("Municipal Routing Agent", "Incident Created",
                                f"Operational incident [{incident['id'][:8]}] created. "
                                f"Dept: {incident['department']} | SLA: {incident['sla_hours']}h",
                                "completed", [incident["id"]])

                # Step 3: Trigger route optimization for high-priority incidents
                if incident["risk_level"] in ("high", "critical"):
                    _emit_activity("Prediction Agent", "Risk Assessment",
                                    f"Ward {incident['ward_id']} flagged as {incident['risk_level'].upper()} overflow risk. "
                                    "Triggering route recalculation...",
                                    "active", [incident["id"]])

                    routes = await route_agent.optimize_routes(
                        incident["ward_id"],
                        datetime.now().strftime("%Y-%m-%d"),
                    )
                    if routes:
                        _emit_activity("Route Optimization Agent", "Routes Optimized",
                                        f"Generated {len(routes)} optimized route(s). "
                                        f"Total stops: {sum(len(r.get('stops',[])) for r in routes)}. "
                                        f"Efficiency gain: {routes[0].get('efficiency_vs_baseline_pct',0):.1f}%",
                                        "completed", [r["id"] for r in routes])

                # Pending human approval for high-impact actions
                if incident.get("requires_human_approval"):
                    _emit_activity("Municipal Routing Agent", "Awaiting Approval",
                                    f"High-impact action pending officer approval. "
                                    f"Incident [{incident['id'][:8]}] requires authorization.",
                                    "waiting", [incident["id"]])
        else:
            _emit_activity("Municipal Routing Agent", "Complaint Routed",
                            f"[{ticket_id}] Routed to {result['department']}. No cluster formed.",
                            "completed", [ticket_id])

        # Step 4: Citizen notification
        _emit_activity("Grievance Agent", "Citizen Notified",
                        f"Confirmation sent to citizen in {result['detected_language'].upper()}. "
                        f"Ticket: {ticket_id}",
                        "completed", [ticket_id])

        return {**result, "workflow_id": workflow_id}

    # ──────────────────────────────────────────
    # WORKFLOW: Morning system scan
    # ──────────────────────────────────────────

    async def run_morning_scan(self, ward_ids: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Automated morning operational scan.
        Runs hotspot prediction, compliance check, SLA scan.
        """
        if not ward_ids:
            ward_ids = ["ward_07", "ward_12", "ward_05"]

        _emit_activity("Orchestrator", "Morning Scan Started",
                        f"Scanning {len(ward_ids)} wards...", "active")

        results = {}

        for ward_id in ward_ids:
            # Hotspot prediction
            predictions = await hotspot_agent.predict_hotspots(ward_id)
            critical = [p for p in predictions if p.get("risk_level") == "critical"]
            high = [p for p in predictions if p.get("risk_level") == "high"]
            _emit_activity("Prediction Agent", "Hotspot Analysis",
                            f"{ward_id}: {len(critical)} CRITICAL, {len(high)} HIGH risk locations detected.",
                            "completed", [ward_id])

            # Compliance check
            compliance = compliance_agent.get_ward_compliance_score(ward_id)
            if compliance["level"] in ("low", "critical"):
                _emit_activity("Segregation Compliance Agent", "Compliance Alert",
                                f"{ward_id}: Compliance {compliance['score']:.1f}% ({compliance['level'].upper()}, {compliance['trend']}). "
                                "Generating nudges...",
                                "active", [ward_id])
                nudges = await compliance_agent.generate_multilingual_nudges(ward_id)
                _emit_activity("Segregation Compliance Agent", "Nudges Generated",
                                f"3 multilingual nudges prepared for {ward_id} residents.",
                                "completed", [ward_id])

            # Route optimization
            routes = await route_agent.optimize_routes(ward_id, datetime.now().strftime("%Y-%m-%d"))
            _emit_activity("Route Optimization Agent", "Routes Generated",
                            f"{ward_id}: {len(routes)} route(s) optimized. "
                            f"Avg efficiency gain: {sum(r.get('efficiency_vs_baseline_pct',0) for r in routes)/max(len(routes),1):.1f}%",
                            "completed", [ward_id])

            results[ward_id] = {
                "hotspots": len(predictions),
                "critical_hotspots": len(critical),
                "compliance_score": compliance["score"],
                "routes_generated": len(routes),
            }

        # SLA breach check
        breaches = await routing_agent.check_sla_breaches()
        if breaches:
            _emit_activity("Municipal Routing Agent", "SLA Breaches Detected",
                            f"{len(breaches)} incident(s) breaching SLA. Auto-escalating...",
                            "active")

        _emit_activity("Orchestrator", "Morning Scan Complete",
                        f"Scan complete. {sum(v['critical_hotspots'] for v in results.values())} critical issues require attention.",
                        "completed")
        return {"ward_results": results, "sla_breaches": len(breaches), "scanned_at": datetime.now().isoformat()}

    # ──────────────────────────────────────────
    # WORKFLOW: Demo scenario (Hero Demo)
    # ──────────────────────────────────────────

    async def run_hero_demo(self) -> Dict[str, Any]:
        """
        Complete hero demo scenario for Ward 7.
        Shows full OBSERVE→REASON→ACT→VERIFY→LEARN cycle.
        """
        _emit_activity("Orchestrator", "🚀 Hero Demo Started",
                        "SWACHH-AI COMMAND demo initiated for Ward 7 - Bapunagar", "active")
        await asyncio.sleep(0.1)

        # 1. Detect rising waste
        _emit_activity("Ward Analytics Agent", "📊 Anomaly Detected",
                        "Ward 7 waste generation trending UP 17% over 7 days. Segregation compliance DECLINING (-11%).",
                        "active", ["ward_07"])
        await asyncio.sleep(0.1)

        # 2. Hotspot prediction
        _emit_activity("Prediction Agent", "🔮 Overflow Predicted",
                        "Bapunagar Market: CRITICAL (94.2/100). Shiv Shakti Society: HIGH (78.5/100). "
                        "Weekend market activity confirmed +32% volume.",
                        "completed", ["hot_001", "hot_002"])
        await asyncio.sleep(0.1)

        # 3. Grievance clustering
        _emit_activity("Grievance Agent", "📨 3 Complaints Received",
                        "3 overflowing bin complaints in 2h from Ward 7 market area. "
                        "Languages: Gujarati, English, Hindi. Clustering...",
                        "completed", ["cmp_002", "cmp_003", "cmp_006"])
        await asyncio.sleep(0.1)

        _emit_activity("Municipal Routing Agent", "🔗 Complaints Clustered",
                        "3 complaints → 1 operational incident. Priority escalated to CRITICAL. "
                        "Department: Solid Waste Collection. SLA: 2 hours.",
                        "completed", ["clust_002", "inc_002"])
        await asyncio.sleep(0.1)

        # 4. Route optimization
        _emit_activity("Route Optimization Agent", "🗺️ Route Recalculated",
                        "Optimized route for VEH-01 (large, 85% fuel). 6 stops → 3h 20min. "
                        "Efficiency: +18% vs baseline. Bapunagar Market = Stop #1 (critical priority).",
                        "completed", ["route_ward_07_veh_01"])
        await asyncio.sleep(0.1)

        # 5. Citizen nudges
        _emit_activity("Segregation Compliance Agent", "💬 Nudges Sent",
                        "Segregation reminder sent to 18,600 Ward 7 households in Gujarati, Hindi, English.",
                        "completed", ["ward_07"])
        await asyncio.sleep(0.1)

        # 6. Human approval checkpoint
        _emit_activity("Municipal Routing Agent", "🟡 Awaiting Officer Approval",
                        "HIGH-IMPACT action pending. Officer Priya Sharma notified. "
                        "Incident inc_002 requires authorization before vehicle dispatch.",
                        "waiting", ["inc_002"])
        await asyncio.sleep(0.1)

        # 7. Approval (simulated)
        _emit_activity("Officer Action", "✅ Approved by Officer",
                        "Officer Priya Sharma approved emergency dispatch. Resources authorized.",
                        "completed", ["inc_002"])
        await asyncio.sleep(0.1)

        # 8. Execution
        _emit_activity("Vehicle Operations", "🚛 Vehicle Dispatched",
                        "VEH-01 (GJ-01-WM-0001) dispatched to Bapunagar Market. ETA: 12 minutes.",
                        "active", ["veh_01", "inc_002"])
        await asyncio.sleep(0.1)

        # 9. Resolution
        _emit_activity("Route Optimization Agent", "✅ Collection Completed",
                        "Bapunagar Market bin cleared. 6/6 collection points serviced. "
                        "Total waste collected: 1,847kg. Route completed in 3h 15min.",
                        "completed", ["route_ward_07_veh_01"])
        await asyncio.sleep(0.1)

        # 10. Citizen notification
        _emit_activity("Grievance Agent", "📲 Citizens Notified",
                        "3 complaint reporters notified: Issue resolved. "
                        "Confirmation sent in Gujarati, English, Hindi.",
                        "completed", ["cmp_002", "cmp_003", "cmp_006"])
        await asyncio.sleep(0.1)

        # 11. Analytics update
        _emit_activity("Ward Analytics Agent", "📈 Analytics Updated",
                        "Ward 7 dashboard refreshed. Incident closed. "
                        "Cleanliness score updated: 52.4 → 61.8. Route efficiency recorded.",
                        "completed", ["ward_07"])

        return {
            "demo_completed": True,
            "ward": "ward_07",
            "incidents_handled": 2,
            "complaints_resolved": 5,
            "routes_optimized": 1,
            "vehicles_dispatched": 1,
            "citizens_notified": 3,
            "nudges_sent": 18600,
            "sla_met": True,
            "efficiency_improvement_pct": 18,
        }

    # ──────────────────────────────────────────
    # ACTIVITY STREAM
    # ──────────────────────────────────────────

    def get_activity_stream(self, limit: int = 50) -> List[Dict]:
        return list(reversed(_activity_stream[-limit:]))

    def get_agent_statuses(self) -> List[Dict]:
        """Return current status of all agents."""
        agents = [
            {"id": "agent_route", "name": "Route Optimization Agent", "icon": "🗺️"},
            {"id": "agent_compliance", "name": "Segregation Compliance Agent", "icon": "♻️"},
            {"id": "agent_grievance", "name": "Grievance Intake Agent", "icon": "📨"},
            {"id": "agent_routing", "name": "Municipal Routing Agent", "icon": "🏛️"},
            {"id": "agent_hotspot", "name": "Predictive Hotspot Agent", "icon": "🔮"},
            {"id": "agent_analytics", "name": "Ward Analytics Agent", "icon": "📊"},
            {"id": "agent_circular", "name": "Circular Economy Agent", "icon": "🌿"},
        ]
        # Check latest activity for each agent
        for agent in agents:
            latest = next(
                (a for a in reversed(_activity_stream)
                 if agent["name"] in a.get("agent_name", "")),
                None
            )
            agent["status"] = latest["status"] if latest else "idle"
            agent["last_action"] = latest["action"] if latest else "Standby"
            agent["last_detail"] = latest["detail"][:60] if latest else "Ready"
            agent["last_seen"] = latest["timestamp"] if latest else datetime.now().isoformat()
        return agents


# Singleton orchestrator
orchestrator = AgentOrchestrator()
