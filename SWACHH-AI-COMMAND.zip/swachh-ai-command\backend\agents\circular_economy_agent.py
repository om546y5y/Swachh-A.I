"""
SWACHH-AI COMMAND — Circular Economy Intelligence Agent
Analyzes waste composition and recommends recycling, composting, material recovery.
All estimates clearly labeled as DEMO SIMULATION.
"""

import logging
from datetime import datetime
from typing import Dict, Any, List

from backend.services.granite_service import generate_circular_economy_insight
from backend.data.seed_data import (
    CIRCULAR_ECONOMY_DATA, MATERIAL_RECOVERY_VALUES, WASTE_HISTORY, WARDS
)

logger = logging.getLogger(__name__)


class CircularEconomyAgent:
    """
    Agent G — Circular Economy Intelligence
    Extends beyond collection: analyzes composition, recommends recovery pathways.
    NOTE: All figures are ESTIMATES — labeled as DEMO SIMULATION.
    """

    def __init__(self):
        self.name = "Circular Economy Agent"
        self.agent_id = "agent_circular"
        logger.info(f"{self.name} initialized")

    def calculate_recovery_potential(self, ward_id: str, period_days: int = 30) -> Dict[str, Any]:
        """
        Calculate estimated circular economy potential for a ward.
        Returns recovery volumes, values, and environmental impact.
        """
        ward_records = sorted(
            [r for r in WASTE_HISTORY if r["ward_id"] == ward_id],
            key=lambda r: r["date"], reverse=True
        )[:period_days]

        if not ward_records:
            return {"error": "No data available"}

        total_kg = sum(r["total_kg"] for r in ward_records)
        total_wet = sum(r["wet_kg"] for r in ward_records)
        total_dry = sum(r["dry_kg"] for r in ward_records)

        # Get ward CE profile
        ce_data = CIRCULAR_ECONOMY_DATA.get(ward_id, CIRCULAR_ECONOMY_DATA.get("ward_07", {}))
        dry_comp = ce_data.get("dry_waste_composition", {"paper": 0.30, "plastic": 0.28, "metal": 0.12, "glass": 0.08})

        # Current recovery rates
        current_recycling_rate = ce_data.get("current_recycling_rate", 0.15)
        current_composting_rate = ce_data.get("current_composting_rate", 0.06)

        # Potential rates (with AI-optimized sorting and community participation)
        potential_recycling_rate = ce_data.get("potential_recycling_rate", 0.40)
        potential_composting_rate = ce_data.get("potential_composting_rate", 0.32)

        # Current recovery
        current_recycled_kg = total_dry * current_recycling_rate
        current_composted_kg = total_wet * current_composting_rate

        # Potential recovery
        potential_recycled_kg = total_dry * potential_recycling_rate
        potential_composted_kg = total_wet * potential_composting_rate

        # Gap (opportunity)
        additional_recyclable = potential_recycled_kg - current_recycled_kg
        additional_compostable = potential_composted_kg - current_composted_kg

        # Material breakdown of dry waste
        material_breakdown = {}
        total_dry_potential = total_dry * potential_recycling_rate
        for material, fraction in dry_comp.items():
            kg = total_dry_potential * fraction
            value_per_ton = MATERIAL_RECOVERY_VALUES.get(material, 5000)
            material_breakdown[material] = {
                "kg": round(kg, 1),
                "recovery_value_inr": round(kg * value_per_ton / 1000, 0),
            }

        # Total recovery value
        total_recovery_value = sum(
            v["recovery_value_inr"] for v in material_breakdown.values()
        ) + potential_composted_kg * MATERIAL_RECOVERY_VALUES["compost"] / 1000

        # Environmental impact (simplified estimates)
        landfill_diverted = additional_recyclable + additional_compostable
        co2_saved_kg = landfill_diverted * 0.82  # rough CO2e per kg diverted from landfill

        # Current vs AI-optimized
        current_landfill_kg = total_kg - current_recycled_kg - current_composted_kg
        potential_landfill_kg = total_kg - potential_recycled_kg - potential_composted_kg
        landfill_reduction_pct = ((current_landfill_kg - potential_landfill_kg) / current_landfill_kg * 100) if current_landfill_kg else 0

        return {
            "ward_id": ward_id,
            "period_days": period_days,
            "total_waste_kg": round(total_kg, 1),
            "current_state": {
                "recycled_kg": round(current_recycled_kg, 1),
                "composted_kg": round(current_composted_kg, 1),
                "landfill_kg": round(current_landfill_kg, 1),
                "recycling_rate_pct": round(current_recycling_rate * 100, 1),
                "composting_rate_pct": round(current_composting_rate * 100, 1),
            },
            "ai_optimized_potential": {
                "recycled_kg": round(potential_recycled_kg, 1),
                "composted_kg": round(potential_composted_kg, 1),
                "landfill_kg": round(potential_landfill_kg, 1),
                "recycling_rate_pct": round(potential_recycling_rate * 100, 1),
                "composting_rate_pct": round(potential_composting_rate * 100, 1),
            },
            "opportunity": {
                "additional_recyclable_kg": round(additional_recyclable, 1),
                "additional_compostable_kg": round(additional_compostable, 1),
                "landfill_diverted_kg": round(landfill_diverted, 1),
                "landfill_reduction_pct": round(landfill_reduction_pct, 1),
                "co2_saved_kg_estimate": round(co2_saved_kg, 1),
                "recovery_value_inr_estimate": round(total_recovery_value, 0),
            },
            "material_breakdown": material_breakdown,
            "recommendations": self._get_recommendations(
                current_recycling_rate, potential_recycling_rate,
                current_composting_rate, potential_composting_rate
            ),
            "note": "DEMO SIMULATION — All figures are estimates for demonstration. Not actual government data.",
            "calculated_at": datetime.now().isoformat(),
        }

    def _get_recommendations(self, curr_rec: float, pot_rec: float,
                               curr_comp: float, pot_comp: float) -> List[Dict]:
        recommendations = []
        if pot_rec - curr_rec > 0.1:
            recommendations.append({
                "category": "Dry Waste Recovery",
                "action": "Establish dry waste collection center (DWCC) partnerships with rag-pickers",
                "potential_gain_pct": round((pot_rec - curr_rec) * 100, 1),
                "timeline": "3-6 months",
            })
        if pot_comp - curr_comp > 0.1:
            recommendations.append({
                "category": "Organic Composting",
                "action": "Deploy community composting units in high-density residential societies",
                "potential_gain_pct": round((pot_comp - curr_comp) * 100, 1),
                "timeline": "2-4 months",
            })
        recommendations.append({
            "category": "Source Segregation",
            "action": "AI-guided door-to-door segregation compliance with real-time feedback",
            "potential_gain_pct": 15,
            "timeline": "Immediate",
        })
        recommendations.append({
            "category": "Hazardous Waste",
            "action": "Monthly e-waste/hazardous collection drives in industrial zones",
            "potential_gain_pct": 8,
            "timeline": "Monthly",
        })
        return recommendations

    async def get_ward_circular_report(self, ward_id: str) -> Dict[str, Any]:
        """Full circular economy report with Granite AI insights."""
        report = self.calculate_recovery_potential(ward_id)
        insight = await generate_circular_economy_insight({
            "ward_id": ward_id,
            "total_waste_kg": report.get("total_waste_kg"),
            "current_recycling_rate": report["current_state"]["recycling_rate_pct"],
            "potential_recycling_rate": report["ai_optimized_potential"]["recycling_rate_pct"],
            "landfill_reduction_pct": report["opportunity"]["landfill_reduction_pct"],
            "recovery_value_inr": report["opportunity"]["recovery_value_inr_estimate"],
        })
        report["ai_insight"] = insight
        return report

    def get_city_circular_summary(self) -> Dict[str, Any]:
        """City-wide circular economy opportunity summary."""
        all_ward_ids = [w["id"] for w in WARDS]
        total_recovery_value = 0
        total_landfill_diverted = 0
        total_co2_saved = 0

        for wid in all_ward_ids:
            rpt = self.calculate_recovery_potential(wid, 30)
            opp = rpt.get("opportunity", {})
            total_recovery_value += opp.get("recovery_value_inr_estimate", 0)
            total_landfill_diverted += opp.get("landfill_diverted_kg", 0)
            total_co2_saved += opp.get("co2_saved_kg_estimate", 0)

        return {
            "total_monthly_recovery_value_inr": round(total_recovery_value, 0),
            "total_monthly_landfill_diverted_kg": round(total_landfill_diverted, 1),
            "total_monthly_co2_saved_kg": round(total_co2_saved, 1),
            "wards_covered": len(all_ward_ids),
            "note": "DEMO SIMULATION — Estimated city-wide figures",
        }


circular_agent = CircularEconomyAgent()
