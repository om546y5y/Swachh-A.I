"""
SWACHH-AI COMMAND — Municipal Routing Agent
Operational orchestration: routes grievances, assigns tasks, manages SLA, escalates.
Detects repeated problems. Coordinates between all agents.
High-impact actions require human approval.
"""

import uuid
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any

from backend.services.granite_service import generate_ai_decision_rationale
from backend.data.seed_data import INCIDENTS, OFFICERS

logger = logging.getLogger(__name__)

_incidents: List[Dict] = list(INCIDENTS)
_task_queue: List[Dict] = []
_audit_logs: List[Dict] = []


class MunicipalRoutingAgent:
    """
    Agent D — Municipal Routing & Orchestration
    Routes incidents, assigns departments, manages SLA, escalates issues.
    Human-in-the-loop: high-priority actions require officer approval.
    """

    def __init__(self):
        self.name = "Municipal Routing Agent"
        self.agent_id = "agent_routing"
        logger.info(f"{self.name} initialized")

    async def create_incident_from_cluster(self, cluster: Dict,
                                            complaints: List[Dict]) -> Dict[str, Any]:
        """Convert a complaint cluster into an operational incident."""
        complaint_type = cluster.get("complaint_type", "other")
        priority = cluster.get("priority", 3)
        ward_id = cluster.get("ward_id", "unknown")
        count = len(cluster.get("complaint_ids", []))

        # Determine risk level from priority
        risk_map = {5: "critical", 4: "high", 3: "medium", 2: "low", 1: "low"}
        risk_level = risk_map.get(priority, "medium")

        # Department and SLA
        dept_map = {
            "overflowing_bin": "Solid Waste Collection",
            "missed_collection": "Solid Waste Collection",
            "illegal_dumping": "Emergency/High Priority",
            "damaged_bin": "Solid Waste Collection",
            "sanitation_issue": "Sanitation",
            "vehicle_not_arrived": "Vehicle Operations",
        }
        department = dept_map.get(complaint_type, "Ward Supervisor")
        sla_hours = 2 if risk_level == "critical" else (4 if risk_level == "high" else 8)

        # AI recommendation
        incident_id = str(uuid.uuid4())
        title = f"{complaint_type.replace('_',' ').title()} — {ward_id} ({count} complaints)"

        rationale = await generate_ai_decision_rationale(
            decision_type=f"Incident creation: {complaint_type}",
            data_considered={
                "complaint_count": count,
                "ward": ward_id,
                "cluster_radius_m": cluster.get("radius_meters", 500),
                "priority": priority,
                "complaint_type": complaint_type,
            },
            recommendation=f"Create {risk_level.upper()} priority incident, assign to {department}",
            confidence=0.88,
            expected_result=f"Incident resolved within {sla_hours} hours SLA"
        )

        incident = {
            "id": incident_id,
            "title": title,
            "description": cluster.get("ai_summary", f"{count} complaints clustered."),
            "ward_id": ward_id,
            "location": cluster.get("location"),
            "cluster_id": cluster["id"],
            "complaint_ids": cluster.get("complaint_ids", []),
            "priority": priority,
            "risk_level": risk_level,
            "department": department,
            "status": "pending_approval" if priority >= 4 else "approved",
            "sla_hours": sla_hours,
            "sla_deadline": (datetime.now() + timedelta(hours=sla_hours)).isoformat(),
            "ai_recommendation": f"Dispatch {department} team immediately. {cluster.get('ai_summary', '')}",
            "ai_rationale": str(rationale),
            "requires_human_approval": priority >= 4,
            "created_at": datetime.now().isoformat(),
            "resolved_at": None,
            "approved_by": None,
        }
        _incidents.append(incident)
        self._log_audit("system_agent", "agent", "create_incident", "incident", incident_id,
                        None, incident, f"Auto-created from cluster {cluster['id']}")
        return incident

    async def approve_incident(self, incident_id: str, officer_id: str,
                                decision: str, reason: Optional[str] = None) -> Dict:
        """Officer approves/rejects/modifies a pending incident action."""
        incident = next((i for i in _incidents if i["id"] == incident_id), None)
        if not incident:
            return {"success": False, "error": "Incident not found"}

        old_status = incident["status"]
        if decision == "approve":
            incident["status"] = "approved"
            incident["approved_by"] = officer_id
            incident["approved_at"] = datetime.now().isoformat()
            msg = f"Incident {incident_id} approved by {officer_id}. Dispatching resources."
        elif decision == "reject":
            incident["status"] = "rejected"
            incident["rejected_by"] = officer_id
            incident["rejected_reason"] = reason
            msg = f"Incident {incident_id} rejected by {officer_id}."
        elif decision == "modify":
            incident["status"] = "approved"
            incident["approved_by"] = officer_id
            incident["officer_notes"] = reason
            msg = f"Incident {incident_id} approved with modifications by {officer_id}."
        else:
            return {"success": False, "error": "Invalid decision"}

        self._log_audit(officer_id, "officer", f"incident_{decision}", "incident",
                        incident_id, {"status": old_status}, {"status": incident["status"]}, reason)
        return {"success": True, "incident_id": incident_id, "status": incident["status"], "message": msg}

    async def resolve_incident(self, incident_id: str, resolved_by: str,
                                notes: Optional[str] = None) -> Dict:
        """Mark incident as resolved and trigger citizen notifications."""
        incident = next((i for i in _incidents if i["id"] == incident_id), None)
        if not incident:
            return {"success": False, "error": "Incident not found"}

        incident["status"] = "completed"
        incident["resolved_at"] = datetime.now().isoformat()
        incident["resolution_notes"] = notes

        # Calculate resolution time
        created = datetime.fromisoformat(incident["created_at"])
        resolved = datetime.now()
        hours_taken = (resolved - created).total_seconds() / 3600
        incident["resolution_hours"] = round(hours_taken, 2)
        incident["sla_met"] = hours_taken <= incident.get("sla_hours", 8)

        self._log_audit(resolved_by, "officer", "resolve_incident", "incident",
                        incident_id, {"status": "approved"}, {"status": "completed"}, notes)
        return {
            "success": True,
            "incident_id": incident_id,
            "resolution_hours": round(hours_taken, 2),
            "sla_met": incident["sla_met"],
            "message": f"Incident resolved in {hours_taken:.1f} hours. SLA {'met ✓' if incident['sla_met'] else 'breached ✗'}."
        }

    async def check_sla_breaches(self) -> List[Dict]:
        """Detect and escalate SLA breaches."""
        breaches = []
        now = datetime.now()
        for incident in _incidents:
            if incident["status"] in ("pending_approval", "approved"):
                deadline = incident.get("sla_deadline")
                if deadline:
                    dl = datetime.fromisoformat(deadline)
                    if now > dl:
                        overdue_hours = (now - dl).total_seconds() / 3600
                        breaches.append({
                            "incident_id": incident["id"],
                            "title": incident["title"],
                            "ward_id": incident["ward_id"],
                            "overdue_hours": round(overdue_hours, 1),
                            "department": incident["department"],
                            "priority": incident["priority"],
                            "escalation_action": f"Auto-escalate to Ward Supervisor. Overdue by {overdue_hours:.1f}h.",
                        })
                        # Auto-escalate
                        if overdue_hours > 1 and incident.get("priority", 0) < 5:
                            incident["priority"] = min(5, incident["priority"] + 1)
                            incident["escalated"] = True
        return breaches

    def get_all_incidents(self, ward_id: Optional[str] = None,
                           status: Optional[str] = None) -> List[Dict]:
        incidents = _incidents
        if ward_id:
            incidents = [i for i in incidents if i.get("ward_id") == ward_id]
        if status:
            incidents = [i for i in incidents if i.get("status") == status]
        return sorted(incidents, key=lambda i: i.get("priority", 0), reverse=True)

    def get_pending_approvals(self) -> List[Dict]:
        return [i for i in _incidents if i.get("status") == "pending_approval"]

    def get_audit_logs(self, resource_type: Optional[str] = None) -> List[Dict]:
        logs = _audit_logs
        if resource_type:
            logs = [l for l in logs if l.get("resource_type") == resource_type]
        return sorted(logs, key=lambda l: l.get("timestamp", ""), reverse=True)

    def _log_audit(self, actor_id: str, actor_role: str, action: str,
                   resource_type: str, resource_id: str, before: Any,
                   after: Any, reason: Optional[str] = None):
        _audit_logs.append({
            "id": str(uuid.uuid4()),
            "actor_id": actor_id,
            "actor_role": actor_role,
            "action": action,
            "resource_type": resource_type,
            "resource_id": resource_id,
            "before_state": before,
            "after_state": after,
            "reason": reason,
            "timestamp": datetime.now().isoformat(),
        })


routing_agent = MunicipalRoutingAgent()
