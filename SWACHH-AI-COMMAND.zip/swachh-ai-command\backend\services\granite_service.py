"""
SWACHH-AI COMMAND — IBM Granite LLM Service
Handles all LLM interactions using IBM watsonx.ai Granite models.
Granite is used for: language understanding, intent detection, NL explanation,
citizen communication, insight generation, and decision rationale.
Deterministic algorithms handle routing math, SLA, and scoring.
"""

import os
import json
import logging
from typing import Optional, Dict, Any
import httpx

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# IBM watsonx.ai Configuration
# ─────────────────────────────────────────────

WATSONX_API_KEY = os.getenv("WATSONX_API_KEY", "")
WATSONX_PROJECT_ID = os.getenv("WATSONX_PROJECT_ID", "")
WATSONX_URL = os.getenv("WATSONX_URL", "https://us-south.ml.cloud.ibm.com")
GRANITE_MODEL_ID = os.getenv("GRANITE_MODEL_ID", "ibm/granite-13b-instruct-v2")
GRANITE_CHAT_MODEL_ID = os.getenv("GRANITE_CHAT_MODEL_ID", "ibm/granite-3-8b-instruct")

# Token cache
_iam_token: Optional[str] = None
_token_expiry: float = 0.0


async def _get_iam_token() -> str:
    """Get IAM bearer token for watsonx.ai authentication."""
    global _iam_token, _token_expiry
    import time
    if _iam_token and time.time() < _token_expiry - 60:
        return _iam_token
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                "https://iam.cloud.ibm.com/identity/token",
                data={
                    "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
                    "apikey": WATSONX_API_KEY,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            resp.raise_for_status()
            data = resp.json()
            _iam_token = data["access_token"]
            _token_expiry = time.time() + int(data.get("expires_in", 3600))
            return _iam_token
    except Exception as e:
        logger.warning(f"IBM IAM token fetch failed: {e}. Using mock mode.")
        return "MOCK_TOKEN"


async def _call_granite(prompt: str, max_tokens: int = 400, temperature: float = 0.3) -> str:
    """
    Core Granite inference call.
    Falls back to intelligent mock responses when API is unavailable (demo mode).
    """
    if not WATSONX_API_KEY or WATSONX_API_KEY == "your-api-key-here":
        return _mock_granite_response(prompt)

    try:
        token = await _get_iam_token()
        if token == "MOCK_TOKEN":
            return _mock_granite_response(prompt)

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        payload = {
            "model_id": GRANITE_CHAT_MODEL_ID,
            "input": prompt,
            "parameters": {
                "decoding_method": "greedy",
                "max_new_tokens": max_tokens,
                "min_new_tokens": 10,
                "temperature": temperature,
                "repetition_penalty": 1.05,
                "stop_sequences": ["<|endoftext|>", "\n\nHuman:", "\n\nUser:"],
            },
            "project_id": WATSONX_PROJECT_ID,
        }
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(
                f"{WATSONX_URL}/ml/v1/text/generation?version=2023-05-29",
                headers=headers,
                json=payload,
            )
            resp.raise_for_status()
            result = resp.json()
            return result["results"][0]["generated_text"].strip()
    except Exception as e:
        logger.warning(f"Granite API call failed: {e}. Using mock response.")
        return _mock_granite_response(prompt)


def _mock_granite_response(prompt: str) -> str:
    """
    Intelligent mock responses for demo/offline mode.
    Returns realistic, contextually appropriate responses.
    """
    prompt_lower = prompt.lower()

    # Language detection
    if "detect language" in prompt_lower or "language of" in prompt_lower:
        if any(c in prompt for c in "ઘઉઈઆ"):
            return json.dumps({"language": "gu", "confidence": 0.97})
        elif any(c in prompt for c in "कबसम"):
            return json.dumps({"language": "hi", "confidence": 0.95})
        return json.dumps({"language": "en", "confidence": 0.99})

    # Complaint classification
    if "classify" in prompt_lower and "complaint" in prompt_lower:
        if any(w in prompt_lower for w in ["overflow", "full", "bharai", "bhar"]):
            return json.dumps({"type": "overflowing_bin", "urgency": 4, "confidence": 0.92,
                               "rationale": "Complaint describes bin overflow condition requiring urgent attention."})
        if any(w in prompt_lower for w in ["missed", "nahi aavi", "aavi nathi", "nahi aayi"]):
            return json.dumps({"type": "missed_collection", "urgency": 3, "confidence": 0.89,
                               "rationale": "Complaint indicates collection vehicle did not arrive at scheduled time."})
        if any(w in prompt_lower for w in ["dump", "illegal", "roadside"]):
            return json.dumps({"type": "illegal_dumping", "urgency": 4, "confidence": 0.88,
                               "rationale": "Illegal dumping poses public health and environmental risk."})
        return json.dumps({"type": "other", "urgency": 2, "confidence": 0.75,
                           "rationale": "General waste management complaint requiring standard processing."})

    # Translation to English
    if "translate" in prompt_lower and "english" in prompt_lower:
        if "આવી નથી" in prompt or "gaadi" in prompt_lower:
            return "The garbage collection vehicle has not come to our area today."
        if "bharaai" in prompt_lower or "kachranu" in prompt_lower:
            return "The garbage bin is overflowing and needs urgent attention."
        return "Citizen has reported a waste management issue in their area."

    # Citizen notification generation
    if "notification" in prompt_lower or "confirm" in prompt_lower and "ticket" in prompt_lower:
        if "gu" in prompt_lower or "gujarati" in prompt_lower:
            return "આપની ફરિયાદ નોંધવામાં આવી છે. ટિકિટ ID: {ticket_id}. 4 કલાકમાં ઉકેલ મળશે. 📞 1800-SWACHH"
        if "hi" in prompt_lower or "hindi" in prompt_lower:
            return "आपकी शिकायत दर्ज की गई है। टिकिट ID: {ticket_id}। 4 घंटे में समाधान मिलेगा। 📞 1800-SWACHH"
        return "Your complaint has been registered. Ticket ID: {ticket_id}. Expected resolution: 4 hours. 📞 1800-SWACHH"

    # Route explanation
    if "route" in prompt_lower and ("explain" in prompt_lower or "why" in prompt_lower or "rationale" in prompt_lower):
        return ("This optimized route prioritizes the 2 critical overflow locations (Bapunagar Market, Shiv Shakti Society) "
                "first, reducing total distance by 18% compared to the standard sequential route. Vehicle capacity utilization "
                "is estimated at 87%, and the route avoids peak traffic on SG Highway between 8-10 AM. "
                "Expected completion time: 3h 20min with all 6 collection points serviced.")

    # Ward insight generation
    if "ward" in prompt_lower and ("insight" in prompt_lower or "analysis" in prompt_lower or "summary" in prompt_lower):
        return ("Ward 7 is experiencing compounding stress: waste generation has increased 17% over 7 days, "
                "segregation compliance dropped from 60% to 49%, and the Bapunagar Market bin overflow has "
                "generated 3 urgent complaints. The root cause appears to be weekend market activity combined "
                "with a route deviation that missed 2 collection points. Immediate corrective action in the "
                "next 2 hours will prevent escalation to a public health incident.")

    # Nudge generation
    if "nudge" in prompt_lower or "reminder" in prompt_lower or "segregation message" in prompt_lower:
        if "gu" in prompt_lower:
            return ("🌿 સ્વચ્છ ભારત — આપ ફેર ઉપયોગ કરો\n"
                    "ભૂરો ડબ્બો: ભીનો કચરો (શાકભાજી, ખોરાક)\n"
                    "લીલો ડબ્બો: સૂકો કચરો (કાગળ, પ્લાસ્ટિક)\n"
                    "સાથ મળી આપણો વોર્ડ સ્વચ્છ બનાવીએ! 🙏")
        if "hi" in prompt_lower:
            return ("🌿 स्वच्छ भारत — साथ मिलकर बनाएं\n"
                    "नीला डब्बा: गीला कचरा (सब्जी, खाना)\n"
                    "हरा डब्बा: सूखा कचरा (कागज, प्लास्टिक)\n"
                    "आइए मिलकर अपना वार्ड साफ बनाएं! 🙏")
        return ("🌿 Swachh Bharat — Let's segregate together\n"
                "Blue bin: Wet waste (vegetables, food)\n"
                "Green bin: Dry waste (paper, plastic)\n"
                "Together let's keep our ward clean! 🙏")

    # What-if explanation
    if "what if" in prompt_lower or "scenario" in prompt_lower or "simulation" in prompt_lower:
        return ("Based on the simulation parameters, reducing available vehicles from 10 to 8 creates a 22% "
                "increase in route distance and extends average collection time by 47 minutes. Wards 7 and 12 "
                "face the highest overflow risk due to their above-average waste generation. Recommended mitigation: "
                "prioritize high-fill collection points, defer low-priority stops to second shift, "
                "and issue pre-emptive overflow alerts to Ward 7 residents.")

    # Circular economy recommendations
    if "circular" in prompt_lower or "recycl" in prompt_lower or "compost" in prompt_lower:
        return ("Analysis of Ward 7's waste composition reveals significant circular economy opportunity: "
                "28% dry waste contains recoverable paper (30%) and plastic (28%) valued at ₹12,000-25,000/ton. "
                "55% wet waste is compostable with potential for 35kg compost per 100kg organic input. "
                "Implementing source-segregation with material recovery facility integration could divert "
                "an estimated 60% of current landfill-bound waste and generate ₹1.8L/month in recovery value.")

    # Default analytical response
    return ("AI analysis complete. Based on current operational data, the recommended action addresses "
            "the highest-priority issues while optimizing resource utilization. Confidence level: 87%. "
            "Human review recommended for high-impact decisions before execution.")


# ─────────────────────────────────────────────
# PUBLIC API FUNCTIONS
# ─────────────────────────────────────────────

async def detect_language(text: str) -> Dict[str, Any]:
    """Detect language of citizen input text."""
    prompt = f"""Detect the language of the following text and return JSON only.
Text: "{text}"
Return: {{"language": "gu|hi|en", "confidence": 0.0-1.0}}
JSON:"""
    result = await _call_granite(prompt, max_tokens=50)
    try:
        return json.loads(result)
    except Exception:
        # Heuristic fallback
        if any(ord(c) > 2688 and ord(c) < 2815 for c in text):
            return {"language": "gu", "confidence": 0.9}
        elif any(ord(c) > 2304 and ord(c) < 2431 for c in text):
            return {"language": "hi", "confidence": 0.9}
        return {"language": "en", "confidence": 0.85}


async def classify_complaint(text: str, language: str) -> Dict[str, Any]:
    """Classify complaint type, urgency and extract intent."""
    prompt = f"""You are a municipal waste management AI. Classify this citizen complaint.
Language: {language}
Complaint: "{text}"

Classify as one of: missed_collection, overflowing_bin, garbage_dumping, vehicle_not_arrived,
mixed_waste_collection, damaged_bin, illegal_dumping, sanitation_issue, other

Return JSON: {{"type": "...", "urgency": 1-4, "confidence": 0.0-1.0, "rationale": "brief reason"}}
JSON:"""
    result = await _call_granite(prompt, max_tokens=150)
    try:
        data = json.loads(result)
        return data
    except Exception:
        return {"type": "other", "urgency": 2, "confidence": 0.6, "rationale": "Unable to precisely classify"}


async def translate_to_english(text: str, source_language: str) -> str:
    """Translate Gujarati/Hindi complaint to English."""
    if source_language == "en":
        return text
    lang_name = {"gu": "Gujarati", "hi": "Hindi"}.get(source_language, source_language)
    prompt = f"""Translate this {lang_name} text to English. Return only the translation.
{lang_name}: {text}
English:"""
    return await _call_granite(prompt, max_tokens=200)


async def generate_citizen_notification(
    ticket_id: str, complaint_type: str, language: str,
    sla_hours: int, department: str
) -> str:
    """Generate citizen-friendly confirmation message in their language."""
    lang_name = {"gu": "Gujarati", "hi": "Hindi", "en": "English"}.get(language, "English")
    prompt = f"""Generate a friendly citizen notification in {lang_name}.
Ticket ID: {ticket_id}
Issue: {complaint_type}
Department assigned: {department}
Expected resolution: {sla_hours} hours
Include: confirmation, ticket ID, timeline, helpline 1800-SWACHH
{lang_name} message:"""
    msg = await _call_granite(prompt, max_tokens=150)
    return msg.replace("{ticket_id}", ticket_id)


async def generate_route_explanation(route_data: Dict[str, Any]) -> str:
    """Generate natural language explanation for route optimization decision."""
    prompt = f"""Explain this optimized waste collection route decision in 2-3 sentences for a municipal officer.
Route data: {json.dumps(route_data, indent=2)}
Focus on: why this sequence, efficiency gains, priority decisions.
Explanation:"""
    return await _call_granite(prompt, max_tokens=200)


async def generate_ward_insights(analytics_data: Dict[str, Any]) -> Dict[str, str]:
    """Generate 4-part ward insight: what happened, why, recommendation, do-nothing impact."""
    prompt = f"""You are a municipal AI analyst. Generate a 4-part analysis of this ward data.
Ward Analytics: {json.dumps(analytics_data, indent=2)}
Return JSON with these 4 keys (each 1-2 sentences):
{{"what_happened": "...", "why": "...", "recommendation": "...", "do_nothing_impact": "..."}}
JSON:"""
    result = await _call_granite(prompt, max_tokens=400)
    try:
        return json.loads(result)
    except Exception:
        return {
            "what_happened": analytics_data.get("ai_what_happened", "Data analysis in progress."),
            "why": analytics_data.get("ai_why", "Multiple factors contributing."),
            "recommendation": analytics_data.get("ai_recommendation", "Review operational plan."),
            "do_nothing_impact": analytics_data.get("ai_do_nothing_impact", "Situation may worsen."),
        }


async def generate_segregation_nudge(ward_id: str, language: str,
                                      compliance_score: float, trend: str) -> str:
    """Generate appropriate citizen nudge based on compliance behavior."""
    nudge_type = "educational" if compliance_score < 50 else ("positive_reinforcement" if trend == "improving" else "reminder")
    lang_name = {"gu": "Gujarati", "hi": "Hindi", "en": "English"}.get(language, "English")
    prompt = f"""Generate a {nudge_type} waste segregation message in {lang_name}.
Ward compliance: {compliance_score:.1f}% (trend: {trend})
Message type: {nudge_type}
Keep it short (3-4 lines), friendly, actionable.
{lang_name} message:"""
    return await _call_granite(prompt, max_tokens=120)


async def generate_hotspot_recommendation(hotspot_data: Dict[str, Any]) -> str:
    """Generate natural language recommendation for a predicted hotspot."""
    prompt = f"""You are a municipal waste operations AI. Provide a clear operational recommendation.
Hotspot data: {json.dumps(hotspot_data, indent=2)}
Format: Risk → Reason → Action → Expected Impact (2-3 sentences)
Recommendation:"""
    return await _call_granite(prompt, max_tokens=200)


async def generate_what_if_explanation(scenario: Dict, results: Dict) -> str:
    """Explain what-if simulation results in plain language."""
    prompt = f"""Explain the following municipal waste what-if simulation results to an officer.
Scenario: {json.dumps(scenario)}
Results: {json.dumps(results)}
Plain English explanation (3-4 sentences, focus on operational impact):"""
    return await _call_granite(prompt, max_tokens=250)


async def generate_circular_economy_insight(waste_data: Dict[str, Any]) -> str:
    """Generate circular economy opportunity analysis."""
    prompt = f"""Analyze this ward waste composition data and identify circular economy opportunities.
Data: {json.dumps(waste_data)}
Focus on: recyclable recovery, composting potential, landfill diversion, estimated value.
Note: Clearly label all figures as ESTIMATES.
Analysis (3-4 sentences):"""
    return await _call_granite(prompt, max_tokens=300)


async def generate_ai_decision_rationale(
    decision_type: str, data_considered: Dict, recommendation: str,
    confidence: float, expected_result: str
) -> Dict[str, Any]:
    """Generate 'Why AI?' explanation for any major recommendation."""
    prompt = f"""Generate a transparent AI decision explanation for a municipal officer.
Decision type: {decision_type}
Data considered: {json.dumps(data_considered)}
Recommendation: {recommendation}
Confidence: {confidence:.0%}

Return JSON: {{
  "data_considered": ["list of key data points"],
  "important_factors": ["list of factors"],
  "constraints": ["list of constraints"],
  "confidence_pct": {int(confidence*100)},
  "expected_result": "{expected_result}"
}}
JSON:"""
    result = await _call_granite(prompt, max_tokens=400)
    try:
        return json.loads(result)
    except Exception:
        return {
            "data_considered": list(data_considered.keys())[:5],
            "important_factors": ["Waste volume trend", "Collection history", "Vehicle availability"],
            "constraints": ["Vehicle capacity", "Route time window", "Staff availability"],
            "confidence_pct": int(confidence * 100),
            "expected_result": expected_result,
        }


async def extract_location_from_text(text: str, ward_hints: list) -> Optional[Dict]:
    """Extract location information from complaint text."""
    prompt = f"""Extract location information from this complaint text.
Text: "{text}"
Known ward names: {ward_hints}
Return JSON: {{"location_found": true/false, "location_name": "...", "ward_hint": "..."}}
JSON:"""
    result = await _call_granite(prompt, max_tokens=100)
    try:
        return json.loads(result)
    except Exception:
        return {"location_found": False, "location_name": None, "ward_hint": None}
