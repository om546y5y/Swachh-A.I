"""
SWACHH-AI COMMAND — Grievance Intake Agent (Multilingual)
Supports Gujarati, Hindi, English. Text input with voice-ready architecture.
Uses IBM Granite for language detection, classification, translation.
"""

import uuid
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List

from backend.services.granite_service import (
    detect_language, classify_complaint, translate_to_english,
    generate_citizen_notification, extract_location_from_text,
    generate_ai_decision_rationale
)
from backend.data.seed_data import WARDS, SAMPLE_COMPLAINTS, COMPLAINT_CLUSTERS

logger = logging.getLogger(__name__)

# In-memory store (production: IBM Cloudant / PostgreSQL)
_complaints: List[Dict] = list(SAMPLE_COMPLAINTS)
_clusters: List[Dict] = list(COMPLAINT_CLUSTERS)
_ticket_counter = 10  # start after seed data

# SLA hours by complaint type
SLA_BY_TYPE = {
    "missed_collection": 4,
    "overflowing_bin": 2,
    "garbage_dumping": 3,
    "vehicle_not_arrived": 4,
    "mixed_waste_collection": 6,
    "damaged_bin": 24,
    "illegal_dumping": 2,
    "sanitation_issue": 8,
    "other": 12,
}

DEPARTMENT_BY_TYPE = {
    "missed_collection": "Solid Waste Collection",
    "overflowing_bin": "Solid Waste Collection",
    "garbage_dumping": "Solid Waste Collection",
    "vehicle_not_arrived": "Vehicle Operations",
    "mixed_waste_collection": "Solid Waste Collection",
    "damaged_bin": "Solid Waste Collection",
    "illegal_dumping": "Emergency/High Priority",
    "sanitation_issue": "Sanitation",
    "other": "Ward Supervisor",
}

# Clustering threshold: group within this radius (km)
CLUSTER_RADIUS_KM = 0.5
CLUSTER_TIME_WINDOW_HOURS = 4


class GrievanceIntakeAgent:
    """
    Agent C — Multilingual Grievance Intake
    OBSERVE: citizen text input
    UNDERSTAND: language, intent, complaint type
    REASON: classify, prioritize, check for duplicates/clusters
    DECIDE: create new ticket or merge into cluster
    ACT: generate ticket, route to department, notify citizen
    VERIFY: SLA deadline set, confirmation sent
    LEARN: cluster patterns improve routing intelligence
    """

    def __init__(self):
        self.name = "Grievance Intake Agent"
        self.agent_id = "agent_grievance"
        logger.info(f"{self.name} initialized")

    async def process_complaint(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """
        Full complaint processing pipeline.
        Returns ticket + confirmation + cluster status.
        """
        global _ticket_counter
        text = request.get("text", "")
        if not text.strip():
            return {"error": "Empty complaint text", "success": False}

        activities = []

        # STEP 1: Detect language (Granite)
        lang_result = await detect_language(text)
        language = lang_result.get("language", "en")
        lang_confidence = lang_result.get("confidence", 0.8)
        activities.append({
            "agent": self.name, "step": "Language Detection",
            "detail": f"Detected: {language.upper()} (confidence: {lang_confidence:.0%})",
            "status": "completed"
        })

        # STEP 2: Translate if needed
        english_text = await translate_to_english(text, language)
        activities.append({
            "agent": self.name, "step": "Translation",
            "detail": f"Translated to English: '{english_text[:80]}...'",
            "status": "completed"
        })

        # STEP 3: Classify complaint (Granite)
        classification = await classify_complaint(text, language)
        complaint_type = classification.get("type", "other")
        urgency = classification.get("urgency", 2)
        ai_confidence = classification.get("confidence", 0.7)
        activities.append({
            "agent": self.name, "step": "Intent Classification",
            "detail": f"Type: {complaint_type} | Urgency: {urgency}/4 | Confidence: {ai_confidence:.0%}",
            "status": "completed"
        })

        # STEP 4: Extract location
        ward_names = [w["name"] for w in WARDS]
        location_result = await extract_location_from_text(text, ward_names)
        location = request.get("location")
        ward_id = request.get("ward_id")
        if location_result.get("location_found") and not location:
            activities.append({
                "agent": self.name, "step": "Location Extraction",
                "detail": f"Extracted location: {location_result.get('location_name', 'Unknown')}",
                "status": "completed"
            })
        elif location:
            activities.append({
                "agent": self.name, "step": "Location",
                "detail": f"User-provided location: {location.get('address', 'GPS coordinates')}",
                "status": "completed"
            })

        # STEP 5: Determine department and SLA
        department = DEPARTMENT_BY_TYPE.get(complaint_type, "Ward Supervisor")
        sla_hours = SLA_BY_TYPE.get(complaint_type, 8)
        priority = urgency  # urgency directly maps to priority
        sla_deadline = (datetime.now() + timedelta(hours=sla_hours)).isoformat()

        # STEP 6: Generate ticket
        _ticket_counter += 1
        ticket_id = f"TKT-2024-{_ticket_counter:04d}"
        complaint_id = str(uuid.uuid4())

        complaint = {
            "id": complaint_id,
            "ticket_id": ticket_id,
            "text_original": text,
            "text_english": english_text,
            "language": language,
            "complaint_type": complaint_type,
            "location": location,
            "location_description": request.get("location_description"),
            "ward_id": ward_id,
            "urgency": urgency,
            "priority": priority,
            "status": "open",
            "department": department,
            "sla_hours": sla_hours,
            "sla_deadline": sla_deadline,
            "citizen_phone": request.get("citizen_phone"),
            "created_at": datetime.now().isoformat(),
            "ai_classification_confidence": ai_confidence,
            "ai_rationale": classification.get("rationale", ""),
            "cluster_id": None,
        }
        _complaints.append(complaint)
        activities.append({
            "agent": self.name, "step": "Ticket Generated",
            "detail": f"Ticket: {ticket_id} | Dept: {department} | SLA: {sla_hours}h",
            "status": "completed"
        })

        # STEP 7: Duplicate/cluster detection
        cluster_info = await self._check_and_cluster(complaint)
        if cluster_info:
            complaint["status"] = "clustered"
            complaint["cluster_id"] = cluster_info["cluster_id"]
            activities.append({
                "agent": self.name, "step": "Cluster Detection",
                "detail": f"⚠️ Grouped with {cluster_info['cluster_size']-1} similar complaint(s) → Incident priority elevated",
                "status": "completed"
            })
        else:
            activities.append({
                "agent": self.name, "step": "Cluster Detection",
                "detail": "No duplicate cluster found. New independent ticket created.",
                "status": "completed"
            })

        # STEP 8: Generate citizen notification (Granite)
        notification_msg = await generate_citizen_notification(
            ticket_id=ticket_id,
            complaint_type=complaint_type.replace("_", " ").title(),
            language=language,
            sla_hours=sla_hours,
            department=department,
        )
        activities.append({
            "agent": self.name, "step": "Citizen Notification",
            "detail": f"Confirmation sent in {language.upper()}",
            "status": "completed"
        })

        return {
            "success": True,
            "ticket_id": ticket_id,
            "complaint_id": complaint_id,
            "detected_language": language,
            "complaint_type": complaint_type,
            "translated_text": english_text,
            "urgency": urgency,
            "priority": priority,
            "department": department,
            "sla_hours": sla_hours,
            "sla_deadline": sla_deadline,
            "confirmation_message": notification_msg,
            "cluster_info": cluster_info,
            "ai_confidence": ai_confidence,
            "activities": activities,
        }

    async def _check_and_cluster(self, complaint: Dict) -> Optional[Dict]:
        """
        Intelligent duplicate grievance detection.
        Groups complaints by type, location proximity, and time window.
        """
        if not complaint.get("location"):
            return None

        comp_loc = complaint["location"]
        comp_type = complaint["complaint_type"]
        comp_time = datetime.fromisoformat(complaint["created_at"])

        # Find matching cluster
        for cluster in _clusters:
            if cluster["complaint_type"] != comp_type:
                continue
            # Check time window
            cluster_time = datetime.fromisoformat(cluster["created_at"])
            if abs((comp_time - cluster_time).total_seconds()) > CLUSTER_TIME_WINDOW_HOURS * 3600:
                continue
            # Check spatial proximity
            from backend.agents.route_optimization_agent import haversine_km
            dist = haversine_km(
                comp_loc["lat"], comp_loc["lng"],
                cluster["location"]["lat"], cluster["location"]["lng"]
            )
            if dist <= CLUSTER_RADIUS_KM:
                # Add to existing cluster
                cluster["complaint_ids"].append(complaint["id"])
                cluster["priority"] = min(5, cluster.get("priority", 3) + 1)
                cluster["ai_summary"] = (
                    f"{len(cluster['complaint_ids'])} {comp_type.replace('_',' ')} complaints "
                    f"clustered within {CLUSTER_RADIUS_KM*1000:.0f}m of {cluster['location'].get('address','this area')}. "
                    f"Elevated to priority {cluster['priority']}."
                )
                return {
                    "cluster_id": cluster["id"],
                    "cluster_size": len(cluster["complaint_ids"]),
                    "priority": cluster["priority"],
                    "location": cluster["location"],
                    "summary": cluster["ai_summary"],
                }

        # Create new cluster if ≥2 similar complaints nearby
        nearby_same_type = []
        for c in _complaints:
            if (c["id"] != complaint["id"]
                    and c.get("complaint_type") == comp_type
                    and c.get("location")):
                from backend.agents.route_optimization_agent import haversine_km
                dist = haversine_km(
                    comp_loc["lat"], comp_loc["lng"],
                    c["location"]["lat"], c["location"]["lng"]
                )
                c_time = datetime.fromisoformat(c.get("created_at", datetime.now().isoformat()))
                if dist <= CLUSTER_RADIUS_KM and abs((comp_time - c_time).total_seconds()) <= CLUSTER_TIME_WINDOW_HOURS * 3600:
                    nearby_same_type.append(c)

        if nearby_same_type:
            cluster_id = str(uuid.uuid4())
            all_ids = [c["id"] for c in nearby_same_type] + [complaint["id"]]
            new_cluster = {
                "id": cluster_id,
                "complaint_ids": all_ids,
                "complaint_type": comp_type,
                "location": comp_loc,
                "ward_id": complaint.get("ward_id"),
                "radius_meters": CLUSTER_RADIUS_KM * 1000,
                "priority": 4,
                "status": "open",
                "incident_id": None,
                "created_at": datetime.now().isoformat(),
                "ai_summary": (
                    f"{len(all_ids)} {comp_type.replace('_',' ')} complaints clustered. "
                    "AI detected pattern — creating unified incident for operational response."
                ),
            }
            _clusters.append(new_cluster)
            # Update existing complaints
            for c in nearby_same_type:
                c["cluster_id"] = cluster_id
                c["status"] = "clustered"
            return {
                "cluster_id": cluster_id,
                "cluster_size": len(all_ids),
                "priority": 4,
                "location": comp_loc,
                "summary": new_cluster["ai_summary"],
                "is_new_cluster": True,
            }

        return None

    def get_all_complaints(self, ward_id: Optional[str] = None,
                            status: Optional[str] = None) -> List[Dict]:
        complaints = _complaints
        if ward_id:
            complaints = [c for c in complaints if c.get("ward_id") == ward_id]
        if status:
            complaints = [c for c in complaints if c.get("status") == status]
        return sorted(complaints, key=lambda c: c.get("created_at", ""), reverse=True)

    def get_clusters(self, ward_id: Optional[str] = None) -> List[Dict]:
        clusters = _clusters
        if ward_id:
            clusters = [c for c in clusters if c.get("ward_id") == ward_id]
        return sorted(clusters, key=lambda c: c.get("priority", 0), reverse=True)

    def get_complaint_by_ticket(self, ticket_id: str) -> Optional[Dict]:
        return next((c for c in _complaints if c.get("ticket_id") == ticket_id), None)

    def update_complaint_status(self, complaint_id: str, status: str,
                                  resolved_at: Optional[str] = None) -> bool:
        for c in _complaints:
            if c["id"] == complaint_id:
                c["status"] = status
                if resolved_at:
                    c["resolved_at"] = resolved_at
                return True
        return False


# Singleton
grievance_agent = GrievanceIntakeAgent()
