"""
SWACHH-AI COMMAND — Core Data Models
All Pydantic models for the municipal waste management platform.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum
import uuid


# ─────────────────────────────────────────────
# ENUMS
# ─────────────────────────────────────────────

class WasteType(str, Enum):
    WET = "wet"
    DRY = "dry"
    MIXED = "mixed"
    HAZARDOUS = "hazardous"

class ComplianceLevel(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    CRITICAL = "critical"

class ComplaintType(str, Enum):
    MISSED_COLLECTION = "missed_collection"
    OVERFLOWING_BIN = "overflowing_bin"
    GARBAGE_DUMPING = "garbage_dumping"
    VEHICLE_NOT_ARRIVED = "vehicle_not_arrived"
    MIXED_WASTE_COLLECTION = "mixed_waste_collection"
    DAMAGED_BIN = "damaged_bin"
    ILLEGAL_DUMPING = "illegal_dumping"
    SANITATION_ISSUE = "sanitation_issue"
    OTHER = "other"

class ComplaintStatus(str, Enum):
    OPEN = "open"
    CLUSTERED = "clustered"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    CLOSED = "closed"

class Department(str, Enum):
    SOLID_WASTE = "Solid Waste Collection"
    SANITATION = "Sanitation"
    VEHICLE_OPS = "Vehicle Operations"
    WARD_SUPERVISOR = "Ward Supervisor"
    EMERGENCY = "Emergency/High Priority"

class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class ActionStatus(str, Enum):
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXECUTING = "executing"
    COMPLETED = "completed"

class Language(str, Enum):
    GUJARATI = "gu"
    HINDI = "hi"
    ENGLISH = "en"

class AgentStatus(str, Enum):
    IDLE = "idle"
    ACTIVE = "active"
    WAITING = "waiting"
    COMPLETED = "completed"
    ERROR = "error"


# ─────────────────────────────────────────────
# LOCATION
# ─────────────────────────────────────────────

class GeoPoint(BaseModel):
    lat: float
    lng: float
    address: Optional[str] = None

class Ward(BaseModel):
    id: str
    name: str
    city: str = "Ahmedabad"
    population: int
    area_sqkm: float
    center: GeoPoint
    households: int
    societies: List[str] = []

class Society(BaseModel):
    id: str
    name: str
    ward_id: str
    location: GeoPoint
    household_count: int
    contact: Optional[str] = None

class Household(BaseModel):
    id: str
    society_id: str
    ward_id: str
    address: str
    member_count: int
    registration_date: str


# ─────────────────────────────────────────────
# WASTE & COLLECTION
# ─────────────────────────────────────────────

class CollectionPoint(BaseModel):
    id: str
    ward_id: str
    society_id: Optional[str] = None
    location: GeoPoint
    name: str
    bin_capacity_kg: float = 100.0
    current_fill_percent: float = 0.0
    last_collected: Optional[str] = None
    priority: int = 1  # 1=normal, 2=high, 3=critical
    waste_type_mix: Dict[str, float] = {}

class Vehicle(BaseModel):
    id: str
    registration: str
    vehicle_type: str  # compact, standard, large
    capacity_kg: float
    current_location: GeoPoint
    assigned_ward_ids: List[str] = []
    driver_id: Optional[str] = None
    fuel_level_pct: float = 100.0
    status: str = "available"  # available, on_route, maintenance, offline

class Driver(BaseModel):
    id: str
    name: str
    phone: str
    vehicle_id: Optional[str] = None
    ward_ids: List[str] = []
    shift: str = "morning"  # morning, afternoon, night

class WasteRecord(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    collection_point_id: str
    ward_id: str
    vehicle_id: str
    collected_at: str
    wet_kg: float = 0.0
    dry_kg: float = 0.0
    hazardous_kg: float = 0.0
    mixed_kg: float = 0.0
    total_kg: float = 0.0
    segregation_compliant: bool = False
    notes: Optional[str] = None

class SegregationRecord(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    household_id: Optional[str] = None
    society_id: Optional[str] = None
    ward_id: str
    date: str
    waste_type: WasteType
    correctly_segregated: bool
    collection_point_id: str
    inspector_notes: Optional[str] = None


# ─────────────────────────────────────────────
# COMPLIANCE SCORES
# ─────────────────────────────────────────────

class SegregationScore(BaseModel):
    entity_id: str
    entity_type: str  # household, society, street, ward
    total_collections: int
    compliant_collections: int
    score: float  # 0-100
    level: ComplianceLevel
    trend: str  # improving, declining, stable
    last_updated: str


# ─────────────────────────────────────────────
# COMPLAINTS & GRIEVANCES
# ─────────────────────────────────────────────

class Complaint(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    citizen_id: Optional[str] = None
    citizen_phone: Optional[str] = None
    text_original: str
    text_english: Optional[str] = None
    language: Language = Language.ENGLISH
    complaint_type: ComplaintType
    location: Optional[GeoPoint] = None
    location_description: Optional[str] = None
    ward_id: Optional[str] = None
    urgency: int = 2  # 1=low, 2=medium, 3=high, 4=critical
    priority: int = 2
    status: ComplaintStatus = ComplaintStatus.OPEN
    cluster_id: Optional[str] = None
    department: Optional[Department] = None
    ticket_id: Optional[str] = None
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    resolved_at: Optional[str] = None
    sla_deadline: Optional[str] = None
    ai_classification_confidence: float = 0.0
    ai_rationale: Optional[str] = None

class ComplaintCluster(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    complaint_ids: List[str] = []
    complaint_type: ComplaintType
    location: GeoPoint
    ward_id: str
    radius_meters: float = 500.0
    priority: int = 3
    status: ComplaintStatus = ComplaintStatus.OPEN
    incident_id: Optional[str] = None
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    ai_summary: Optional[str] = None


# ─────────────────────────────────────────────
# INCIDENTS & ROUTING
# ─────────────────────────────────────────────

class Incident(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    description: str
    ward_id: str
    location: Optional[GeoPoint] = None
    cluster_id: Optional[str] = None
    complaint_ids: List[str] = []
    priority: int = 3
    risk_level: RiskLevel = RiskLevel.MEDIUM
    department: Department
    assigned_to: Optional[str] = None
    status: ActionStatus = ActionStatus.PENDING_APPROVAL
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    resolved_at: Optional[str] = None
    sla_hours: int = 4
    sla_deadline: Optional[str] = None
    ai_recommendation: Optional[str] = None
    ai_rationale: Optional[str] = None
    requires_human_approval: bool = True
    approved_by: Optional[str] = None
    approved_at: Optional[str] = None


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────

class RouteStop(BaseModel):
    sequence: int
    collection_point_id: str
    location: GeoPoint
    name: str
    estimated_waste_kg: float
    priority: int
    estimated_arrival: str
    fill_percent: float = 0.0

class Route(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    vehicle_id: str
    ward_id: str
    date: str
    shift: str
    stops: List[RouteStop] = []
    total_distance_km: float = 0.0
    estimated_duration_min: int = 0
    estimated_waste_kg: float = 0.0
    vehicle_capacity_kg: float = 0.0
    capacity_utilization_pct: float = 0.0
    priority_stops: int = 0
    status: str = "proposed"  # proposed, approved, active, completed
    ai_explanation: Optional[str] = None
    efficiency_vs_baseline_pct: float = 0.0
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    approved_by: Optional[str] = None

class RouteAssignment(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    route_id: str
    vehicle_id: str
    driver_id: str
    ward_id: str
    assigned_at: str
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    actual_waste_kg: Optional[float] = None


# ─────────────────────────────────────────────
# HOTSPOT PREDICTIONS
# ─────────────────────────────────────────────

class HotspotPrediction(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    ward_id: str
    location: GeoPoint
    name: str
    risk_level: RiskLevel
    risk_score: float  # 0-100
    reasons: List[str] = []
    recommendation: str
    expected_impact: str
    predicted_overflow_time: Optional[str] = None
    data_inputs: Dict[str, Any] = {}
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    valid_until: str = ""
    ai_confidence: float = 0.0


# ─────────────────────────────────────────────
# WARD ANALYTICS
# ─────────────────────────────────────────────

class WardAnalytics(BaseModel):
    ward_id: str
    ward_name: str
    date: str
    total_waste_kg: float = 0.0
    wet_waste_pct: float = 0.0
    dry_waste_pct: float = 0.0
    mixed_waste_pct: float = 0.0
    hazardous_waste_pct: float = 0.0
    segregation_compliance_pct: float = 0.0
    missed_collections: int = 0
    total_collections: int = 0
    open_grievances: int = 0
    resolved_grievances: int = 0
    avg_resolution_hours: float = 0.0
    route_efficiency_pct: float = 0.0
    vehicle_utilization_pct: float = 0.0
    cleanliness_score: float = 0.0
    active_hotspots: int = 0
    ai_insight: Optional[str] = None
    ai_what_happened: Optional[str] = None
    ai_why: Optional[str] = None
    ai_recommendation: Optional[str] = None
    ai_do_nothing_impact: Optional[str] = None
    trend_waste_7d: List[float] = []
    trend_compliance_7d: List[float] = []
    trend_complaints_7d: List[int] = []


# ─────────────────────────────────────────────
# CIRCULAR ECONOMY
# ─────────────────────────────────────────────

class CircularEconomyReport(BaseModel):
    ward_id: str
    period: str  # weekly, monthly
    date: str
    total_waste_kg: float
    recyclable_recovered_kg: float = 0.0
    organic_diverted_kg: float = 0.0
    landfill_reduction_kg: float = 0.0
    compost_potential_kg: float = 0.0
    dry_recovery_kg: float = 0.0
    estimated_recovery_value_inr: float = 0.0
    co2_saved_kg: float = 0.0
    recycling_rate_pct: float = 0.0
    landfill_diversion_pct: float = 0.0
    recommendations: List[str] = []
    note: str = "DEMO SIMULATION — Estimated figures for demonstration purposes only"


# ─────────────────────────────────────────────
# AI AGENT ACTIVITY
# ─────────────────────────────────────────────

class AgentActivity(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    agent_name: str
    action: str
    detail: str
    status: AgentStatus
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    related_ids: List[str] = []
    duration_ms: Optional[int] = None

class AgentWorkflow(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    trigger: str
    activities: List[AgentActivity] = []
    status: str = "running"  # running, waiting_approval, completed, failed
    started_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    completed_at: Optional[str] = None


# ─────────────────────────────────────────────
# NOTIFICATIONS
# ─────────────────────────────────────────────

class Notification(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    recipient_id: str
    recipient_type: str  # citizen, officer, driver
    channel: str  # sms, push, email
    language: Language = Language.ENGLISH
    subject: str
    message: str
    sent_at: Optional[str] = None
    delivered: bool = False
    related_complaint_id: Optional[str] = None
    related_incident_id: Optional[str] = None


# ─────────────────────────────────────────────
# WHAT-IF SIMULATION
# ─────────────────────────────────────────────

class WhatIfScenario(BaseModel):
    ward_id: str
    waste_volume_change_pct: float = 0.0        # e.g. +25 = 25% more waste
    vehicles_available: Optional[int] = None
    collection_delay_hours: float = 0.0
    segregation_rate_pct: Optional[float] = None
    complaints_count: Optional[int] = None
    notes: Optional[str] = None

class WhatIfResult(BaseModel):
    scenario: WhatIfScenario
    baseline_routes: int
    recommended_routes: int
    distance_change_pct: float
    time_change_pct: float
    overflow_risk_change: str
    affected_wards: List[str]
    route_modifications: List[str]
    high_risk_areas: List[str]
    mitigation_steps: List[str]
    ai_explanation: str
    cost_impact_inr: float = 0.0
    note: str = "DEMO SIMULATION"


# ─────────────────────────────────────────────
# AUDIT LOGS
# ─────────────────────────────────────────────

class AuditLog(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    actor_id: str
    actor_role: str
    action: str
    resource_type: str
    resource_id: str
    before_state: Optional[Dict] = None
    after_state: Optional[Dict] = None
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    ip_address: Optional[str] = None
    reason: Optional[str] = None


# ─────────────────────────────────────────────
# API REQUEST/RESPONSE SHAPES
# ─────────────────────────────────────────────

class GrievanceRequest(BaseModel):
    text: str
    language: Optional[Language] = None
    location: Optional[GeoPoint] = None
    location_description: Optional[str] = None
    citizen_phone: Optional[str] = None
    ward_id: Optional[str] = None

class GrievanceResponse(BaseModel):
    ticket_id: str
    detected_language: Language
    complaint_type: ComplaintType
    translated_text: Optional[str] = None
    urgency: int
    priority: int
    department: Department
    message: str  # confirmation in citizen's language
    sla_hours: int
    cluster_info: Optional[str] = None
    workflow_id: str

class RouteOptimizationRequest(BaseModel):
    ward_id: str
    date: str
    shift: str = "morning"
    vehicles: Optional[List[str]] = None
    force_recalculate: bool = False

class ApprovalRequest(BaseModel):
    officer_id: str
    decision: str  # approve, reject, modify
    reason: Optional[str] = None
    modified_params: Optional[Dict] = None
