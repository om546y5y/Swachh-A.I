"""
SWACHH-AI COMMAND — Route Optimization Agent
Uses deterministic algorithms (nearest-neighbor + priority weighting) for routing.
IBM Granite provides natural language explanations.
"""

import math
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Tuple, Optional, Any
from copy import deepcopy

from backend.services.granite_service import generate_route_explanation, generate_ai_decision_rationale
from backend.data.seed_data import COLLECTION_POINTS, VEHICLES

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────

SPEED_KMH = 20.0          # average urban municipal vehicle speed
SERVICE_TIME_MIN = 8.0    # minutes at each collection point
PRIORITY_WEIGHTS = {1: 1.0, 2: 1.5, 3: 2.5}  # priority multipliers
OVERFLOW_THRESHOLD = 85.0  # fill % above which point becomes priority 3


# ─────────────────────────────────────────────
# HAVERSINE DISTANCE
# ─────────────────────────────────────────────

def haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """Calculate great-circle distance between two GPS coordinates in km."""
    R = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lng2 - lng1)
    a = math.sin(dphi/2)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda/2)**2
    return R * 2 * math.asin(math.sqrt(a))


def total_route_distance(points: List[Dict], start: Dict) -> float:
    """Calculate total route distance including return to depot."""
    total = 0.0
    prev = start
    for pt in points:
        loc = pt["location"]
        total += haversine_km(prev["lat"], prev["lng"], loc["lat"], loc["lng"])
        prev = loc
    # return to start
    if points:
        last = points[-1]["location"]
        total += haversine_km(last["lat"], last["lng"], start["lat"], start["lng"])
    return round(total, 2)


# ─────────────────────────────────────────────
# PRIORITY-WEIGHTED NEAREST NEIGHBOR ALGORITHM
# ─────────────────────────────────────────────

def priority_nearest_neighbor(
    collection_points: List[Dict],
    start_location: Dict,
    vehicle_capacity_kg: float,
) -> Tuple[List[Dict], float, float]:
    """
    Optimized route using priority-weighted nearest neighbor heuristic.
    Priority overflow points and high-fill bins are visited first when close.
    Returns: (ordered_route, total_distance_km, total_estimated_waste_kg)
    """
    # Elevate priority for overflow bins
    points = deepcopy(collection_points)
    for pt in points:
        if pt.get("current_fill_percent", 0) >= OVERFLOW_THRESHOLD:
            pt["priority"] = max(pt.get("priority", 1), 3)

    # Score = distance / priority_weight (lower = visit sooner)
    unvisited = list(range(len(points)))
    route = []
    current_loc = start_location
    total_waste = 0.0

    while unvisited:
        best_idx = None
        best_score = float("inf")

        for i in unvisited:
            pt = points[i]
            loc = pt["location"]
            dist = haversine_km(
                current_loc["lat"], current_loc["lng"],
                loc["lat"], loc["lng"]
            )
            # Urgency: priority 3 (critical) uses weight 2.5 → lower effective score
            priority_w = PRIORITY_WEIGHTS.get(pt.get("priority", 1), 1.0)
            score = dist / priority_w
            if score < best_score:
                best_score = score
                best_idx = i

        pt = points[best_idx]
        unvisited.remove(best_idx)

        # Estimate waste volume from fill percent and capacity
        est_waste = (pt.get("current_fill_percent", 50) / 100.0) * pt.get("bin_capacity_kg", 100)
        total_waste += est_waste

        # Compute estimated arrival time
        dist_from_last = haversine_km(
            current_loc["lat"], current_loc["lng"],
            pt["location"]["lat"], pt["location"]["lng"]
        )
        travel_min = (dist_from_last / SPEED_KMH) * 60
        route.append({**pt, "_estimated_waste_kg": round(est_waste, 1),
                      "_dist_from_prev": round(dist_from_last, 2),
                      "_travel_min": round(travel_min, 1)})
        current_loc = pt["location"]

    total_dist = total_route_distance(points, start_location)
    return route, total_dist, min(total_waste, vehicle_capacity_kg)


def calculate_baseline_distance(points: List[Dict], start: Dict) -> float:
    """Sequential (unoptimized) route distance for comparison."""
    return total_route_distance(points, start)


# ─────────────────────────────────────────────
# ROUTE OPTIMIZATION AGENT
# ─────────────────────────────────────────────

class RouteOptimizationAgent:
    """
    Agent A — Route Optimization
    OBSERVE: vehicle locations, collection points, fill levels, priorities
    UNDERSTAND: capacity constraints, traffic windows, priority urgency
    REASON: algorithmic nearest-neighbor with priority weighting
    DECIDE: optimized stop sequence
    ACT: generate route with explanation
    VERIFY: capacity check, SLA compliance
    LEARN: efficiency tracking vs baseline
    """

    def __init__(self):
        self.name = "Route Optimization Agent"
        self.agent_id = "agent_route"
        logger.info(f"{self.name} initialized")

    async def optimize_routes(
        self,
        ward_id: str,
        date: str,
        shift: str = "morning",
        vehicle_ids: Optional[List[str]] = None,
        scenario_waste_multiplier: float = 1.0,
    ) -> List[Dict[str, Any]]:
        """
        Main optimization function.
        Returns list of optimized route objects for each available vehicle.
        """
        # Get collection points for ward
        ward_points = [cp for cp in COLLECTION_POINTS if cp["ward_id"] == ward_id]
        if not ward_points:
            logger.warning(f"No collection points found for {ward_id}")
            return []

        # Apply scenario multiplier (for what-if)
        if scenario_waste_multiplier != 1.0:
            ward_points = deepcopy(ward_points)
            for pt in ward_points:
                pt["current_fill_percent"] = min(
                    100, pt["current_fill_percent"] * scenario_waste_multiplier
                )

        # Get vehicles for ward
        ward_vehicles = [v for v in VEHICLES
                         if ward_id in v.get("assigned_ward_ids", [])
                         and v["status"] in ("available", "on_route")]
        if vehicle_ids:
            ward_vehicles = [v for v in ward_vehicles if v["id"] in vehicle_ids]
        if not ward_vehicles:
            # Fallback: use any available vehicle
            ward_vehicles = [v for v in VEHICLES if v["status"] == "available"][:2]

        routes = []
        remaining_points = deepcopy(ward_points)

        # Distribute points across vehicles by capacity
        for vehicle in ward_vehicles:
            if not remaining_points:
                break

            vehicle_capacity = vehicle["capacity_kg"]
            start_loc = vehicle["current_location"]

            # Sort: take highest-priority and highest-fill points first for this vehicle
            high_priority = [p for p in remaining_points if p.get("priority", 1) >= 2]
            normal_priority = [p for p in remaining_points if p.get("priority", 1) < 2]

            # Greedy capacity assignment
            assigned = []
            cumulative_waste = 0.0
            for pt in (high_priority + normal_priority):
                est = (pt.get("current_fill_percent", 50) / 100.0) * pt.get("bin_capacity_kg", 100)
                if cumulative_waste + est <= vehicle_capacity * 0.95:  # 5% buffer
                    assigned.append(pt)
                    cumulative_waste += est

            if not assigned:
                assigned = remaining_points[:3]  # ensure at least some stops

            # Remove assigned from remaining
            for pt in assigned:
                if pt in remaining_points:
                    remaining_points.remove(pt)

            # Run optimization
            optimized_stops, opt_dist, total_waste = priority_nearest_neighbor(
                assigned, start_loc, vehicle_capacity
            )
            baseline_dist = calculate_baseline_distance(assigned, start_loc)
            efficiency_gain = ((baseline_dist - opt_dist) / baseline_dist * 100) if baseline_dist > 0 else 0

            # Build route stops with timing
            stops = []
            cumulative_time = 0
            base_time = datetime.now().replace(
                hour=6 if shift == "morning" else 14, minute=0, second=0, microsecond=0
            )

            for i, pt in enumerate(optimized_stops):
                travel_min = pt.get("_travel_min", 5.0)
                cumulative_time += travel_min + SERVICE_TIME_MIN
                est_arrival = base_time + timedelta(minutes=cumulative_time)
                stops.append({
                    "sequence": i + 1,
                    "collection_point_id": pt["id"],
                    "location": pt["location"],
                    "name": pt["name"],
                    "estimated_waste_kg": pt.get("_estimated_waste_kg", 50.0),
                    "priority": pt.get("priority", 1),
                    "estimated_arrival": est_arrival.strftime("%H:%M"),
                    "fill_percent": pt.get("current_fill_percent", 0),
                })

            total_duration = int(cumulative_time)
            capacity_util = (total_waste / vehicle_capacity * 100) if vehicle_capacity > 0 else 0

            route_data = {
                "id": f"route_{ward_id}_{vehicle['id']}_{date}",
                "vehicle_id": vehicle["id"],
                "vehicle_registration": vehicle["registration"],
                "ward_id": ward_id,
                "date": date,
                "shift": shift,
                "stops": stops,
                "total_distance_km": round(opt_dist, 2),
                "baseline_distance_km": round(baseline_dist, 2),
                "estimated_duration_min": total_duration,
                "estimated_waste_kg": round(total_waste, 1),
                "vehicle_capacity_kg": vehicle_capacity,
                "capacity_utilization_pct": round(capacity_util, 1),
                "priority_stops": sum(1 for s in stops if s["priority"] >= 2),
                "status": "proposed",
                "efficiency_vs_baseline_pct": round(efficiency_gain, 1),
                "created_at": datetime.now().isoformat(),
                "scenario_multiplier": scenario_waste_multiplier,
            }

            # Get Granite explanation
            explanation = await generate_route_explanation({
                "ward": ward_id,
                "stops": len(stops),
                "distance_km": opt_dist,
                "baseline_km": baseline_dist,
                "efficiency_gain_pct": round(efficiency_gain, 1),
                "capacity_utilization_pct": round(capacity_util, 1),
                "priority_stops": route_data["priority_stops"],
                "vehicle": vehicle["registration"],
            })
            route_data["ai_explanation"] = explanation

            routes.append(route_data)
            logger.info(f"Route optimized for {vehicle['id']}: {len(stops)} stops, {opt_dist:.1f}km, {efficiency_gain:.1f}% gain")

        return routes

    async def recalculate_route(
        self,
        vehicle_id: str,
        current_location: Dict,
        remaining_points: List[str],
        urgent_additions: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Dynamic rerouting when conditions change mid-route."""
        all_points = {cp["id"]: cp for cp in COLLECTION_POINTS}
        points = [all_points[pid] for pid in remaining_points if pid in all_points]

        # Add urgent additions at highest priority
        if urgent_additions:
            for pid in urgent_additions:
                if pid in all_points:
                    pt = deepcopy(all_points[pid])
                    pt["priority"] = 3  # force highest priority
                    points.insert(0, pt)

        vehicle = next((v for v in VEHICLES if v["id"] == vehicle_id), None)
        capacity = vehicle["capacity_kg"] if vehicle else 2000.0

        optimized, dist, waste = priority_nearest_neighbor(points, current_location, capacity)

        return {
            "vehicle_id": vehicle_id,
            "recalculated_at": datetime.now().isoformat(),
            "reason": f"Dynamic reroute — {len(urgent_additions or [])} urgent addition(s)",
            "new_stops": len(optimized),
            "new_distance_km": round(dist, 2),
            "urgent_additions": urgent_additions or [],
            "route": optimized,
        }

    async def what_if_simulation(
        self,
        ward_id: str,
        waste_multiplier: float = 1.0,
        vehicles_available: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Simulate route impact under changed conditions."""
        # Baseline
        baseline_routes = await self.optimize_routes(ward_id, datetime.now().strftime("%Y-%m-%d"))
        # Scenario
        scenario_routes = await self.optimize_routes(
            ward_id, datetime.now().strftime("%Y-%m-%d"),
            vehicle_ids=None, scenario_waste_multiplier=waste_multiplier,
        )

        baseline_dist = sum(r["total_distance_km"] for r in baseline_routes)
        scenario_dist = sum(r["total_distance_km"] for r in scenario_routes)
        dist_change = ((scenario_dist - baseline_dist) / baseline_dist * 100) if baseline_dist else 0

        # Vehicle reduction impact
        overflow_risk = "LOW"
        if waste_multiplier >= 1.30 or (vehicles_available is not None and vehicles_available < len(baseline_routes)):
            overflow_risk = "HIGH"
        elif waste_multiplier >= 1.15:
            overflow_risk = "MEDIUM"

        high_risk = [f"Bapunagar Market ({ward_id})", "Shiv Shakti Society"] if overflow_risk in ("HIGH", "MEDIUM") else []

        return {
            "ward_id": ward_id,
            "waste_multiplier": waste_multiplier,
            "vehicles_available": vehicles_available or len(baseline_routes),
            "baseline_routes": len(baseline_routes),
            "scenario_routes": len(scenario_routes),
            "baseline_distance_km": round(baseline_dist, 2),
            "scenario_distance_km": round(scenario_dist, 2),
            "distance_change_pct": round(dist_change, 1),
            "overflow_risk": overflow_risk,
            "high_risk_areas": high_risk,
            "estimated_extra_time_min": int(abs(dist_change) * 3),
            "mitigation_steps": self._get_mitigation_steps(waste_multiplier, overflow_risk),
            "note": "DEMO SIMULATION — Estimated figures",
        }

    def _get_mitigation_steps(self, multiplier: float, risk: str) -> List[str]:
        steps = []
        if multiplier >= 1.25:
            steps.append("Dispatch additional collection vehicle to highest-fill locations")
            steps.append("Schedule evening secondary collection run (6–8 PM)")
        if multiplier >= 1.15:
            steps.append("Prioritize overflow collection points in morning route")
            steps.append("Issue citizen notification for potential collection delays")
        if risk in ("HIGH", "CRITICAL"):
            steps.append("Alert Ward Officer for emergency resource allocation")
            steps.append("Activate emergency collection protocol")
        steps.append("Monitor fill levels via real-time telemetry")
        return steps


# Singleton
route_agent = RouteOptimizationAgent()
