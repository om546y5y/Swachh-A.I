"""
SWACHH-AI COMMAND — Ward Analytics Agent
Generates command-center analytics and AI-driven insights.
Answers WHAT HAPPENED / WHY / WHAT TO DO / DO-NOTHING IMPACT.
"""

import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any

from backend.services.granite_service import generate_ward_insights
from backend.data.seed_data import (
    WARD_ANALYTICS_CURRENT, WASTE_HISTORY, SEGREGATION_HISTORY, WARDS
)

logger = logging.getLogger(__name__)


class WardAnalyticsAgent:
    """
    Agent E — Ward Analytics
    NOT just a chart dashboard. Generates actionable AI insights.
    WHAT HAPPENED → WHY → WHAT TO DO → DO-NOTHING IMPACT
    """

    def __init__(self):
        self.name = "Ward Analytics Agent"
        self.agent_id = "agent_analytics"
        logger.info(f"{self.name} initialized")

    def get_ward_analytics(self, ward_id: str) -> Optional[Dict[str, Any]]:
        """Return current analytics for a ward."""
        data = next((w for w in WARD_ANALYTICS_CURRENT if w["ward_id"] == ward_id), None)
        if not data:
            return self._compute_analytics(ward_id)
        return data

    def _compute_analytics(self, ward_id: str) -> Dict[str, Any]:
        """Compute analytics from raw history data."""
        ward_info = next((w for w in WARDS if w["id"] == ward_id), {})
        waste_records = sorted(
            [r for r in WASTE_HISTORY if r["ward_id"] == ward_id],
            key=lambda r: r["date"], reverse=True
        )
        seg_records = sorted(
            [r for r in SEGREGATION_HISTORY if r["ward_id"] == ward_id],
            key=lambda r: r["date"], reverse=True
        )

        recent_waste = waste_records[:7]
        recent_seg = seg_records[:7]

        total_waste = sum(r["total_kg"] for r in recent_waste)
        missed = sum(r.get("missed_collections", 0) for r in recent_waste)
        total_cols = sum(r.get("total_collections", 100) for r in recent_seg)
        compliant = sum(r.get("compliant_collections", 60) for r in recent_seg)

        compliance_pct = (compliant / total_cols * 100) if total_cols else 0
        wet_pct = sum(r.get("wet_kg", 0) for r in recent_waste) / total_waste * 100 if total_waste else 55
        dry_pct = sum(r.get("dry_kg", 0) for r in recent_waste) / total_waste * 100 if total_waste else 30

        trend_waste = [round(r["total_kg"], 1) for r in reversed(recent_waste)]
        trend_compliance = [r["compliance_pct"] for r in reversed(recent_seg)]
        trend_complaints = [r.get("missed_collections", 0) for r in reversed(recent_waste)]

        return {
            "ward_id": ward_id,
            "ward_name": ward_info.get("name", ward_id),
            "date": datetime.now().strftime("%Y-%m-%d"),
            "total_waste_kg": round(total_waste, 1),
            "wet_waste_pct": round(wet_pct, 1),
            "dry_waste_pct": round(dry_pct, 1),
            "mixed_waste_pct": round(100 - wet_pct - dry_pct, 1),
            "segregation_compliance_pct": round(compliance_pct, 1),
            "missed_collections": missed,
            "total_collections": total_cols,
            "open_grievances": 0,
            "resolved_grievances": 0,
            "avg_resolution_hours": 5.0,
            "route_efficiency_pct": 75.0,
            "vehicle_utilization_pct": 72.0,
            "cleanliness_score": round(compliance_pct * 0.5 + (1 - missed/max(total_cols,1)) * 50, 1),
            "active_hotspots": 0,
            "trend_waste_7d": trend_waste,
            "trend_compliance_7d": trend_compliance,
            "trend_complaints_7d": trend_complaints,
        }

    def get_all_ward_analytics(self) -> List[Dict[str, Any]]:
        """Return analytics for all wards."""
        results = list(WARD_ANALYTICS_CURRENT)
        existing_ids = {w["ward_id"] for w in results}
        for ward in WARDS:
            if ward["id"] not in existing_ids:
                results.append(self._compute_analytics(ward["id"]))
        return results

    async def get_ward_ai_insights(self, ward_id: str) -> Dict[str, str]:
        """Get AI-generated insights (what/why/recommend/do-nothing)."""
        analytics = self.get_ward_analytics(ward_id) or {}

        # Use pre-computed insights if available (to keep demo snappy)
        if analytics.get("ai_what_happened"):
            return {
                "what_happened": analytics.get("ai_what_happened", ""),
                "why": analytics.get("ai_why", ""),
                "recommendation": analytics.get("ai_recommendation", ""),
                "do_nothing_impact": analytics.get("ai_do_nothing_impact", ""),
            }

        # Otherwise ask Granite
        return await generate_ward_insights({
            "ward_id": ward_id,
            "ward_name": analytics.get("ward_name"),
            "compliance_pct": analytics.get("segregation_compliance_pct"),
            "missed_collections": analytics.get("missed_collections"),
            "open_grievances": analytics.get("open_grievances"),
            "waste_trend": analytics.get("trend_waste_7d"),
            "compliance_trend": analytics.get("trend_compliance_7d"),
            "active_hotspots": analytics.get("active_hotspots"),
        })

    def get_city_summary(self) -> Dict[str, Any]:
        """High-level city-wide metrics for dashboard header."""
        all_analytics = self.get_all_ward_analytics()
        total_waste = sum(w.get("total_waste_kg", 0) for w in all_analytics)
        avg_compliance = (sum(w.get("segregation_compliance_pct", 0) for w in all_analytics)
                          / len(all_analytics)) if all_analytics else 0
        total_missed = sum(w.get("missed_collections", 0) for w in all_analytics)
        total_open = sum(w.get("open_grievances", 0) for w in all_analytics)
        active_hotspots = sum(w.get("active_hotspots", 0) for w in all_analytics)
        avg_route_eff = (sum(w.get("route_efficiency_pct", 0) for w in all_analytics)
                         / len(all_analytics)) if all_analytics else 0

        worst_ward = min(all_analytics, key=lambda w: w.get("cleanliness_score", 100), default={})
        best_ward = max(all_analytics, key=lambda w: w.get("cleanliness_score", 0), default={})

        return {
            "total_waste_kg_today": round(total_waste, 1),
            "avg_segregation_compliance_pct": round(avg_compliance, 1),
            "total_missed_collections": total_missed,
            "total_open_grievances": total_open,
            "active_hotspots": active_hotspots,
            "avg_route_efficiency_pct": round(avg_route_eff, 1),
            "wards_analyzed": len(all_analytics),
            "worst_ward": worst_ward.get("ward_name", "N/A"),
            "best_ward": best_ward.get("ward_name", "N/A"),
            "as_of": datetime.now().isoformat(),
        }

    def get_trend_data(self, ward_id: str, metric: str, days: int = 30) -> List[Dict]:
        """Return time-series data for charts."""
        if metric == "waste":
            records = sorted(
                [r for r in WASTE_HISTORY if r["ward_id"] == ward_id],
                key=lambda r: r["date"]
            )[-days:]
            return [{"date": r["date"], "value": r["total_kg"]} for r in records]
        elif metric == "compliance":
            records = sorted(
                [r for r in SEGREGATION_HISTORY if r["ward_id"] == ward_id],
                key=lambda r: r["date"]
            )[-days:]
            return [{"date": r["date"], "value": r["compliance_pct"]} for r in records]
        return []

    def get_impact_comparison(self) -> Dict[str, Any]:
        """Baseline vs AI-assisted comparison (clearly labeled DEMO SIMULATION)."""
        return {
            "note": "DEMO SIMULATION — Estimated figures for demonstration purposes only",
            "collection_distance_reduction_pct": 18,
            "fuel_savings_pct": 15,
            "missed_collections_reduction_pct": 62,
            "complaint_resolution_time_reduction_pct": 40,
            "overflow_incidents_reduction_pct": 55,
            "segregation_compliance_improvement_pct": 22,
            "recycling_recovery_improvement_pct": 38,
            "landfill_waste_reduction_pct": 31,
            "annual_cost_savings_inr": 4200000,
            "co2_reduction_tonnes_annual": 142,
        }


analytics_agent = WardAnalyticsAgent()
