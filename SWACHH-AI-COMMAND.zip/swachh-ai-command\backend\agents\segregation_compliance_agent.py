"""
SWACHH-AI COMMAND — Segregation Compliance Agent
Tracks wet/dry/mixed/hazardous waste segregation.
Calculates household, society, ward scores.
Generates intelligent multilingual citizen nudges.
"""

import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any

from backend.services.granite_service import generate_segregation_nudge
from backend.data.seed_data import (
    SEGREGATION_HISTORY, WASTE_HISTORY, SOCIETIES, WARDS
)

logger = logging.getLogger(__name__)


def _compliance_level(score: float) -> str:
    if score >= 75: return "high"
    if score >= 55: return "medium"
    if score >= 35: return "low"
    return "critical"


def _compliance_trend(scores_7d: List[float]) -> str:
    if len(scores_7d) < 3:
        return "stable"
    recent = sum(scores_7d[:3]) / 3
    older = sum(scores_7d[-3:]) / 3
    if recent > older + 3:
        return "improving"
    if recent < older - 3:
        return "declining"
    return "stable"


class SegregationComplianceAgent:
    """
    Agent B — Segregation Compliance Tracking
    OBSERVE: collection records, segregation logs
    UNDERSTAND: patterns, non-compliance hotspots, improving areas
    REASON: score calculation + trend analysis
    DECIDE: appropriate nudge type per area/language
    ACT: generate targeted nudges
    VERIFY: track nudge impact over time
    LEARN: adjust nudge strategy based on compliance change
    """

    def __init__(self):
        self.name = "Segregation Compliance Agent"
        self.agent_id = "agent_compliance"
        logger.info(f"{self.name} initialized")

    def get_ward_compliance_score(self, ward_id: str,
                                   days: int = 7) -> Dict[str, Any]:
        """Calculate current compliance score for a ward."""
        records = [r for r in SEGREGATION_HISTORY
                   if r["ward_id"] == ward_id]
        records_sorted = sorted(records, key=lambda r: r["date"], reverse=True)
        recent = records_sorted[:days]

        if not recent:
            return {"ward_id": ward_id, "score": 0, "level": "critical", "trend": "stable"}

        total = sum(r["total_collections"] for r in recent)
        compliant = sum(r["compliant_collections"] for r in recent)
        score = (compliant / total * 100) if total > 0 else 0

        scores_7d = [r["compliance_pct"] for r in records_sorted[:7]]
        trend = _compliance_trend(scores_7d)

        return {
            "ward_id": ward_id,
            "score": round(score, 1),
            "level": _compliance_level(score),
            "trend": trend,
            "scores_7d": scores_7d,
            "total_collections": total,
            "compliant_collections": compliant,
            "days_analyzed": days,
        }

    def get_all_ward_scores(self) -> List[Dict[str, Any]]:
        """Get compliance scores for all wards."""
        ward_ids = list({r["ward_id"] for r in SEGREGATION_HISTORY})
        results = []
        for wid in ward_ids:
            score_data = self.get_ward_compliance_score(wid)
            ward_info = next((w for w in WARDS if w["id"] == wid), {})
            results.append({
                **score_data,
                "ward_name": ward_info.get("name", wid),
            })
        return sorted(results, key=lambda x: x["score"])

    def identify_problem_areas(self) -> Dict[str, List[Dict]]:
        """Identify high/low/improving/critical compliance areas."""
        all_scores = self.get_all_ward_scores()
        return {
            "critical": [s for s in all_scores if s["level"] == "critical"],
            "low": [s for s in all_scores if s["level"] == "low"],
            "medium": [s for s in all_scores if s["level"] == "medium"],
            "high": [s for s in all_scores if s["level"] == "high"],
            "improving": [s for s in all_scores if s["trend"] == "improving"],
            "declining": [s for s in all_scores if s["trend"] == "declining"],
        }

    def get_waste_type_breakdown(self, ward_id: str, days: int = 7) -> Dict[str, Any]:
        """Get wet/dry/mixed/hazardous breakdown for a ward."""
        records = [r for r in WASTE_HISTORY
                   if r["ward_id"] == ward_id]
        recent = sorted(records, key=lambda r: r["date"], reverse=True)[:days]

        if not recent:
            return {}

        total = sum(r["total_kg"] for r in recent)
        wet = sum(r["wet_kg"] for r in recent)
        dry = sum(r["dry_kg"] for r in recent)
        mixed = sum(r["mixed_kg"] for r in recent)
        hazardous = sum(r["hazardous_kg"] for r in recent)

        return {
            "ward_id": ward_id,
            "period_days": days,
            "total_kg": round(total, 1),
            "wet_pct": round(wet / total * 100, 1) if total else 0,
            "dry_pct": round(dry / total * 100, 1) if total else 0,
            "mixed_pct": round(mixed / total * 100, 1) if total else 0,
            "hazardous_pct": round(hazardous / total * 100, 1) if total else 0,
            "daily_avg_kg": round(total / days, 1) if days else 0,
        }

    async def generate_nudge_for_ward(self, ward_id: str,
                                       language: str = "en") -> Dict[str, Any]:
        """Generate appropriate nudge based on compliance behavior."""
        score_data = self.get_ward_compliance_score(ward_id)
        score = score_data.get("score", 50)
        trend = score_data.get("trend", "stable")
        level = score_data.get("level", "medium")

        # Decide nudge type
        if level == "critical":
            nudge_type = "educational"
            urgency = "high"
        elif level == "low" and trend == "declining":
            nudge_type = "collection-time reminder"
            urgency = "medium"
        elif trend == "improving":
            nudge_type = "positive_reinforcement"
            urgency = "low"
        elif level == "high":
            nudge_type = "community_awareness"
            urgency = "low"
        else:
            nudge_type = "reminder"
            urgency = "medium"

        message = await generate_segregation_nudge(
            ward_id=ward_id,
            language=language,
            compliance_score=score,
            trend=trend,
        )

        return {
            "ward_id": ward_id,
            "compliance_score": score,
            "compliance_level": level,
            "trend": trend,
            "nudge_type": nudge_type,
            "urgency": urgency,
            "language": language,
            "message": message,
            "generated_at": datetime.now().isoformat(),
        }

    async def generate_multilingual_nudges(self, ward_id: str) -> List[Dict]:
        """Generate nudges in all three languages for a ward."""
        nudges = []
        for lang in ["gu", "hi", "en"]:
            nudge = await self.generate_nudge_for_ward(ward_id, lang)
            nudges.append(nudge)
        return nudges

    def get_repeated_noncompliance(self, ward_id: str,
                                    threshold_days: int = 7) -> List[Dict]:
        """Find areas with consistent non-compliance."""
        records = [r for r in SEGREGATION_HISTORY
                   if r["ward_id"] == ward_id]
        recent = sorted(records, key=lambda r: r["date"], reverse=True)[:threshold_days]
        bad_days = [r for r in recent if r["compliance_pct"] < 40]
        if len(bad_days) >= threshold_days // 2:
            return [{
                "ward_id": ward_id,
                "pattern": "repeated_noncompliance",
                "bad_days": len(bad_days),
                "threshold_days": threshold_days,
                "avg_compliance": round(sum(r["compliance_pct"] for r in recent) / len(recent), 1),
                "action": "Deploy compliance officer + educational campaign",
            }]
        return []

    def get_compliance_timeline(self, ward_id: str, days: int = 30) -> List[Dict]:
        """Return daily compliance data for chart rendering."""
        records = [r for r in SEGREGATION_HISTORY if r["ward_id"] == ward_id]
        return sorted(records, key=lambda r: r["date"])[-days:]


compliance_agent = SegregationComplianceAgent()
