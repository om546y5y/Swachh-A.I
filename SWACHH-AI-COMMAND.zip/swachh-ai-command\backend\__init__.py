"""SWACHH-AI COMMAND — Package init files"""
